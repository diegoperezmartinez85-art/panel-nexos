// Vecino: comunicados, reservas de amenities y mascotas contra Supabase (reemplaza al Sheet / Apps Script).
(function(){
  'use strict';
  const sb = () => window.NXSB && NXSB.sb;
  const perfil = () => (window.NXSB && NXSB.perfil) || {};
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const noop = () => {};
  const haptic = t => { try { triggerHaptic(t); } catch (e) {} }, sonido = t => { try { playSound(t); } catch (e) {} };
  const aviso = m => { try { showToast(m); } catch (e) { alert(m); } };

  // ───────── COMUNICADOS ─────────
  const MESES = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  const fcom = iso => { const d = new Date(iso); const h = new Date(); return d.getDate() + ' ' + MESES[d.getMonth()] + (d.getFullYear() === h.getFullYear() ? '' : ' ' + d.getFullYear()); };
  // Foto -> Storage (devuelve la URL pública). Si falla, rechaza.
  window.nxSubirFoto = async function(dataUrl){
    const bin = atob(String(dataUrl).split(',')[1]), u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    const pf = window.NXSB && NXSB.perfil; if (!pf || !pf.barrio_id) throw new Error('Sin sesión');
    const ruta = pf.barrio_id + '/' + (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '' + Math.random().toString(16).slice(2)) + '.jpg';
    const { error } = await sb().storage.from('fotos').upload(ruta, new Blob([u], { type: 'image/jpeg' }), { contentType: 'image/jpeg', cacheControl: '31536000' });
    if (error) throw error;
    return sb().storage.from('fotos').getPublicUrl(ruta).data.publicUrl;
  };
  // Comunicados: una sola consulta compartida (Mural, marquesina y megáfono), con caché corto
  let _comCache = null, _comAt = 0, _comPend = null;
  window.nxTraerComunicados = async function(forzar){
    if (!sb()) return [];
    if (!forzar && _comCache && Date.now() - _comAt < 30000) return _comCache;
    if (_comPend) return _comPend;
    _comPend = (async () => {
      try {
        const { data } = await sb().from('comunicados').select('id,titulo,cuerpo,creado_en,foto').order('creado_en', { ascending: false }).limit(20);
        if (data) { _comCache = data; _comAt = Date.now(); }
      } catch (e) {}
      _comPend = null; return _comCache || [];
    })();
    return _comPend;
  };
  async function traerComunicados(){ return window.nxTraerComunicados(); }
  // Visor de foto a pantalla completa (se cierra tocando en cualquier lado o con la ✕)
  window.nxVerFoto = function(src){
    if (!src) return;
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;z-index:2147483200;background:rgba(0,0,0,.96);display:flex;align-items:center;justify-content:center;padding:12px';
    o.innerHTML = '<img style="max-width:100%;max-height:100%;object-fit:contain;border-radius:8px"><button aria-label="Cerrar" style="position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:14px;width:46px;height:46px;border-radius:50%;border:0;background:rgba(255,255,255,.2);color:#fff;font-size:22px">✕</button>';
    o.querySelector('img').src = src; o.onclick = () => o.remove(); document.body.appendChild(o);
  };
  window.cargarComunicados = async function(){
    const el = document.getElementById('comunicados-lista'); if (!el) return;
    const datos = await traerComunicados();
    el.innerHTML = datos.length ? datos.map((c, i) => `<div class="comunicado-card" style="animation-delay:${i * 0.1}s"><div class="comunicado-card-header"><span class="comunicado-card-title">${esc(c.titulo)}</span><span class="comunicado-card-date">${fcom(c.creado_en)}</span></div>${c.foto ? `<img src="${esc(c.foto)}" data-nxfoto="1" style="display:block;width:100%;max-height:260px;object-fit:cover;border-radius:12px;margin:10px 0 4px;cursor:pointer"><div style="font-size:11px;color:#a1a1aa;margin-bottom:6px">Tocá la foto para verla grande</div>` : ''}<div class="comunicado-card-body">${esc(c.cuerpo)}</div></div>`).join('')
      : '<div style="text-align:center;color:#71717a;padding:30px 10px;font-size:14px">No hay comunicados por ahora.</div>';
    el.querySelectorAll('img[data-nxfoto]').forEach(im => im.onclick = () => window.nxVerFoto(im.src));
  };
  window.marquesinaCargarMural = async function(){
    const datos = await traerComunicados();
    try { _marquesinaData.mural = datos.map(c => '📋 ' + esc(c.titulo) + ' — ' + esc(c.cuerpo)); } catch (e) {}
  };
  window.cargarBaneados = async function(){};   // los bloqueos ahora los resuelve el servidor

  // ───────── RESERVAS ─────────
  const lote = r => 'Mza ' + (r.mza || '-') + ' Casa ' + (r.casa || '-');
  window.cargarDisponibilidadReservas = async function(){
    const cont = document.getElementById('turnos-contenedor'), tit = document.getElementById('turno-fecha-titulo');
    if (!cont || !tit) return;
    const p = reservaSelectedDateStr.split('-'); tit.innerText = p[2] + '/' + p[1] + '/' + p[0];
    cont.innerHTML = '<div style="grid-column:span 2;text-align:center;font-size:11px;color:#71717a;padding:12px 0">Cargando turnos...</div>';
    const { data, error } = await sb().from('reservas').select('*').eq('fecha', reservaSelectedDateStr).ilike('amenity', reservaSelectedAmenity);
    if (error) { cont.innerHTML = '<div style="grid-column:span 2;text-align:center;color:#f87171;font-size:12px">No se pudieron cargar los turnos</div>'; return; }
    const ocup = data || [];
    cont.innerHTML = '';
    obtenerTurnosParaAmenity(reservaSelectedAmenity).forEach(t => {
      const btn = document.createElement('button'); btn.className = 'turno-btn';
      const o = ocup.find(x => x.horario === t);
      if (o) {
        btn.classList.add('reservado');
        btn.innerHTML = `<span class="turno-time">${t}</span><span class="turno-status">🔒 ${o.propietario_id === perfil().id ? 'Tu reserva' : 'Reservado'}</span><span style="font-size:8px;color:#a1a1aa;margin-top:2px">${esc(lote(o))}</span>`;
      } else {
        btn.classList.add('disponible'); if (reservaSelectedSlot === t) btn.classList.add('selected');
        btn.innerHTML = `<span class="turno-time">${t}</span><span class="turno-status">🟢 Disponible</span>`;
        btn.onclick = () => { haptic('soft'); sonido('tap'); reservaSelectedSlot = t; document.querySelectorAll('.turno-btn.disponible').forEach(b => b.classList.remove('selected')); btn.classList.add('selected'); actualizarConfirmBox(); };
      }
      cont.appendChild(btn);
    });
  };
  window.solicitarReserva = async function(){
    if (!reservaSelectedAmenity || !reservaSelectedDateStr || !reservaSelectedSlot) return;
    const pf = perfil(); if (!pf.id) { aviso('Iniciá sesión para reservar'); return; }
    const ni = document.getElementById('reserva-nombre'), ci = document.getElementById('reserva-contacto');
    const { error } = await sb().from('reservas').insert({ barrio_id: pf.barrio_id, propietario_id: pf.id, amenity: reservaSelectedAmenity, fecha: reservaSelectedDateStr,
      horario: reservaSelectedSlot, mza: pf.mza || null, casa: pf.casa || null, nombre: ni ? ni.value.trim() || null : null, contacto: ci ? ci.value.trim() || null : null });
    if (error) {
      haptic('error'); sonido('error');
      if (/reservas_propietario_id_amenity_fecha_key/.test(error.message)) aviso('⚠️ Ya tenés una reserva de ' + reservaSelectedAmenity + ' para este día.');
      else if (/duplicate|unique/i.test(error.message)) aviso('⚠️ Ese turno ya fue reservado por otro vecino.');
      else aviso('❌ No se pudo reservar: ' + error.message);
      cargarDisponibilidadReservas(); return;
    }
    haptic('confirm'); sonido('success'); aviso('✅ Reserva confirmada');
    if (ni) ni.value = ''; if (ci) ci.value = '';
    reservaSelectedSlot = '';
    const box = document.getElementById('reserva-confirm-box'); if (box) box.classList.remove('visible');
    cargarDisponibilidadReservas(); actualizarMisReservasLista();
  };
  window.cancelarReserva = async function(id){
    haptic('error'); sonido('error');
    if (!confirm('¿Confirmás que querés cancelar esta reserva?')) return;
    const { error } = await sb().from('reservas').delete().eq('id', id);
    if (error) { aviso('❌ No se pudo cancelar: ' + error.message); return; }
    haptic('confirm'); sonido('success');
    cargarDisponibilidadReservas(); actualizarMisReservasLista();
  };
  const ICONO = { sum: '🏢 SUM', tenis: '🎾 Cancha de Tenis', quincho: '🍖 Quincho', paddle: '🏓 Cancha de Paddle', futbol: '⚽ Cancha de Fútbol' };
  window.actualizarMisReservasLista = async function(){
    const el = document.getElementById('mis-reservas-lista'); if (!el || !sb() || !perfil().id) return;
    const hoy = new Date(); const hs = hoy.getFullYear() + '-' + String(hoy.getMonth() + 1).padStart(2, '0') + '-' + String(hoy.getDate()).padStart(2, '0');
    const { data } = await sb().from('reservas').select('*').eq('propietario_id', perfil().id).gte('fecha', hs).order('fecha').order('horario');
    if (!data || !data.length) { el.innerHTML = '<div class="no-reservas">No tenés reservas activas agendadas</div>'; return; }
    el.innerHTML = data.map(r => {
      const f = r.fecha.split('-').reverse().join('/');
      return `<div class="mi-reserva-card"><div class="mi-reserva-info"><div class="mi-reserva-title">${ICONO[String(r.amenity).toLowerCase()] || esc(r.amenity)}</div><div class="mi-reserva-date">📅 ${f} — 🕒 ${esc(r.horario)} hs</div>${r.nombre ? `<div class="mi-reserva-date" style="color:#a1a1aa;font-size:10px;margin-top:2px">👤 ${esc(r.nombre)}${r.contacto ? ' · 📞 ' + esc(r.contacto) : ''}</div>` : ''}</div><button class="btn-cancelar-reserva" onclick="cancelarReserva('${r.id}')">CANCELAR</button></div>`;
    }).join('');
  };

  // ───────── MASCOTAS ─────────
  const aPet = m => ({ id: m.id, nombre: m.nombre, raza: m.raza, fotoUrl: m.foto_url || '', telefono: m.telefono || '', notasMedicas: m.notas_medicas || '', mza: m.mza, casa: m.casa, perdida: !!m.perdida_desde, perdidaContacto: m.perdida_contacto || '', perdidaNota: m.perdida_nota || '' });
  window.cargarMisMascotas = async function(){
    const cont = document.getElementById('mascotas-lista-container'); if (!cont) return;
    const pf = perfil();
    if (!pf.id) { cont.innerHTML = '<p style="color:#71717a;text-align:center;font-size:14px">Iniciá sesión para ver tus mascotas.</p>'; return; }
    cont.innerHTML = '<p style="color:#71717a;font-size:14px;text-align:center">Cargando...</p>';
    const { data, error } = await sb().from('mascotas').select('*').eq('mza', pf.mza).eq('casa', pf.casa).order('creado_en');
    if (error) { cont.innerHTML = '<p style="color:#e11d48;font-size:14px;text-align:center">Error cargando mascotas.</p>'; return; }
    if (!data.length) { cont.innerHTML = '<p style="color:#71717a;font-size:14px;text-align:center;margin-top:20px">No tenés mascotas registradas aún.<br>Tocá + Nueva Mascota para empezar.</p>'; return; }
    cont.innerHTML = '';
    data.filter(m => String(m.foto_url || '').startsWith('data:')).forEach(async m => {
      try { const url = await window.nxSubirFoto(m.foto_url); const r = await sb().from('mascotas').update({ foto_url: url }).eq('id', m.id); if (!r.error) { m.foto_url = url; document.querySelectorAll('#mascotas-lista-container img').forEach(im => { if (im.src.startsWith('data:')) im.src = url; }); } } catch (e) {}
    });
    data.map(aPet).forEach(pet => {
      const card = document.createElement('div');
      card.style.cssText = 'background:#27272a;border-radius:16px;padding:16px;margin-bottom:14px;display:flex;align-items:center;gap:14px;';
      card.innerHTML = (pet.fotoUrl ? `<img src="${esc(pet.fotoUrl)}" style="width:56px;height:56px;object-fit:cover;border-radius:50%;border:2px solid #e11d48;flex-shrink:0">` : '<div style="width:56px;height:56px;border-radius:50%;background:#3f3f46;display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0">🐾</div>') +
        `<div style="flex:1;min-width:0"><div style="color:#fff;font-weight:700;font-size:16px;margin-bottom:2px">${esc(pet.nombre)}</div><div style="color:#a1a1aa;font-size:12px;margin-bottom:8px">${esc(pet.raza)}</div><div style="display:flex;gap:8px"></div></div>`;
      const fila = card.querySelector('div[style*="display:flex;gap:8px"]');
      const mk = (txt, css, fn) => { const b = document.createElement('button'); b.textContent = txt; b.style.cssText = 'padding:6px 12px;border-radius:8px;font-size:12px;cursor:pointer;border:none;' + css; b.onclick = fn; fila.appendChild(b); };
      mk('Ver QR', 'background:#e11d48;color:#fff;font-weight:700', () => mostrarQRMascota(pet));
      mk('Editar', 'background:#3f3f46;color:#fff', () => editarMascota(pet));
      if (pet.perdida) {
        card.style.border = '1px solid #f59e0b';
        card.querySelector('div[style*="flex:1"]').insertAdjacentHTML('afterbegin', '<div style="color:#f59e0b;font-size:11px;font-weight:800;letter-spacing:.5px;margin-bottom:4px">🚨 PERDIDA · la garita ya sabe</div>');
        mk('✅ Ya apareció', 'background:#10b981;color:#fff;font-weight:700', () => window.mascotaApareció(pet));
      } else mk('🚨 Se perdió', 'background:#3f3f46;color:#fbbf24;font-weight:700', () => window.mascotaPerdida(pet));
      mk('X', 'background:transparent;color:#71717a;border:1px solid #3f3f46', () => eliminarMascotaBackend(pet.id));
      cont.appendChild(card);
    });
  };
  window.guardarMascotaBackend = async function(){
    const pf = perfil(); const g = id => document.getElementById(id).value.trim();
    const nombre = g('mascota-input-nombre'), raza = g('mascota-input-raza'), id = g('mascota-input-id');
    if (!nombre || !raza) { alert('Completá el nombre y la raza.'); return; }
    const fila = { barrio_id: pf.barrio_id, mza: pf.mza, casa: pf.casa, nombre, raza, foto_url: g('mascota-input-foto') || null, telefono: g('mascota-input-telefono') || null, notas_medicas: g('mascota-input-notas') || null };
    const r = id ? await sb().from('mascotas').update(fila).eq('id', id) : await sb().from('mascotas').insert(fila);
    if (r.error) { alert('Error: ' + r.error.message); return; }
    cerrarEditorMascota(); cargarMisMascotas(); aviso('🐾 Mascota guardada');
  };
  // Mascota perdida: avisa a la garita
  window.mascotaPerdida = function(pet){
    const pf = perfil();
    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;z-index:2147482000;background:rgba(0,0,0,.8);display:flex;align-items:flex-end;justify-content:center;padding:16px;font-family:inherit';
    ov.innerHTML = `<div style="width:100%;max-width:420px;background:#18181b;border:1px solid #3f3f46;border-radius:22px;padding:20px;margin-bottom:12px">
      <div style="font-size:18px;font-weight:800;color:#fbbf24;margin-bottom:4px">🚨 ${esc(pet.nombre)} se perdió</div>
      <div style="color:#a1a1aa;font-size:13px;line-height:1.4;margin-bottom:12px">Le avisamos a la garita con su foto para que lo busquen y estén atentos a la salida.</div>
      <input id="nxmp-t" type="tel" maxlength="40" placeholder="Teléfono para avisarte" value="${esc(pet.telefono || '')}" style="width:100%;box-sizing:border-box;padding:13px;border-radius:12px;border:1px solid #3f3f46;background:#27272a;color:#fff;font-size:15px;margin-bottom:8px">
      <input id="nxmp-n" type="text" maxlength="200" placeholder="Dónde/cuándo lo viste por última vez (opcional)" style="width:100%;box-sizing:border-box;padding:13px;border-radius:12px;border:1px solid #3f3f46;background:#27272a;color:#fff;font-size:15px;margin-bottom:12px">
      <label style="display:flex;gap:10px;align-items:flex-start;margin:2px 0 10px;color:#d4d4d8;font-size:14px;line-height:1.35"><input id="nxmp-mu" type="checkbox" checked style="width:22px;height:22px;margin:0;flex-shrink:0;accent-color:#f59e0b"><span>Avisar también a todos los vecinos en el Mural, con la foto</span></label>
      <div id="nxmp-m" style="color:#f87171;font-size:13px;min-height:16px;margin-bottom:6px"></div>
      <button id="nxmp-ok" style="width:100%;padding:14px;border:0;border-radius:12px;background:#f59e0b;color:#1a1204;font-size:16px;font-weight:800;margin-bottom:8px">Avisar a la garita</button>
      <button id="nxmp-no" style="width:100%;padding:12px;border:0;border-radius:12px;background:transparent;color:#a1a1aa;font-size:14px">Cancelar</button></div>`;
    document.body.appendChild(ov);
    document.getElementById('nxmp-no').onclick = () => ov.remove();
    document.getElementById('nxmp-ok').onclick = async () => {
      const b = document.getElementById('nxmp-ok'), m = document.getElementById('nxmp-m'); b.disabled = true; b.textContent = 'Enviando…';
      const { error } = await sb().from('mascotas').update({ perdida_desde: new Date().toISOString(), perdida_contacto: document.getElementById('nxmp-t').value.trim() || null, perdida_nota: document.getElementById('nxmp-n').value.trim() || null, perdida_mural: document.getElementById('nxmp-mu').checked }).eq('id', pet.id);
      if (error) { m.textContent = 'No se pudo avisar: ' + error.message; b.disabled = false; b.textContent = 'Avisar a la garita'; return; }
      ov.remove(); aviso('🚨 Listo, la garita ya está buscando a ' + pet.nombre); cargarMisMascotas();
    };
  };
  window.mascotaApareció = async function(pet){
    if (!confirm('¿' + pet.nombre + ' ya apareció? Se cierra el aviso en la garita.')) return;
    const { error } = await sb().from('mascotas').update({ perdida_desde: null, perdida_contacto: null, perdida_nota: null }).eq('id', pet.id);
    if (error) { alert('No se pudo cerrar el aviso: ' + error.message); return; }
    aviso('✅ Qué alegría, aviso cerrado'); cargarMisMascotas();
  };
  window.eliminarMascotaBackend = async function(id){
    if (!confirm('¿Seguro que querés eliminar esta mascota?')) return;
    await sb().from('mascotas').delete().eq('id', id); cargarMisMascotas();
  };
  // Ficha pública: la abre cualquiera que escanee la chapita (sin cuenta)
  window.cargarFichaPublicaMascota = async function(petId){
    const screen = document.getElementById('pantalla-mascota-publica'); if (screen) screen.style.display = 'block';
    const { data } = await sb().rpc('mascota_publica', { p_id: petId });
    if (!data || !data.ok) { alert('Mascota no encontrada.'); return; }
    const p = data, set = (id, t) => { const e = document.getElementById(id); if (e) e.textContent = t; };
    set('pub-bienvenida', p.perdida ? '🚨 ¡Estoy perdido! Me llamo ' + p.nombre : 'Hola, me llamo ' + p.nombre + '!');
    if (p.perdida) { const bi = document.getElementById('pub-bienvenida'); if (bi) bi.style.color = '#f59e0b'; if (p.perdidaContacto) p.telefono = p.perdidaContacto; } set('pub-nombre', p.nombre); set('pub-raza', p.raza || ''); set('pub-ubicacion', 'Manzana ' + p.mza + ' - Casa ' + p.casa);
    if (p.fotoUrl) document.getElementById('pub-foto-container').innerHTML = '<img src="' + esc(p.fotoUrl) + '" style="width:140px;height:140px;object-fit:cover;border-radius:50%;border:3px solid #e11d48">';
    if (p.notasMedicas) { const n = document.getElementById('pub-notas'); if (n) n.style.display = 'block'; set('pub-notas-text', p.notasMedicas); }
    if (p.telefono) { const b = document.getElementById('pub-btn-llamar'); if (b) b.onclick = () => window.open('tel:' + p.telefono); }
    window._currentPublicPet = p;
  };
})();

// Al elegir un turno, el cuadro de confirmación se acerca solo a la vista (sin quedar detrás de la barra de abajo)
(function(){
  function vigilar(){
    const box = document.getElementById('reserva-confirm-box');
    if (!box) return setTimeout(vigilar, 800);
    let visto = false;
    new MutationObserver(() => {
      const v = box.classList.contains('visible');
      if (v && !visto) setTimeout(() => { try { box.scrollIntoView({ behavior:'smooth', block:'center' }); } catch(e){} }, 150);
      visto = v;
    }).observe(box, { attributes:true, attributeFilter:['class'] });
  }
  vigilar();
})();
