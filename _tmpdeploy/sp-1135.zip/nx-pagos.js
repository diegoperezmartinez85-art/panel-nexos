// Vecino: informar un pago a la administración (comprobante). Solo lo ven el vecino y la administración de su barrio.
(function(){
  'use strict';
  const sb = () => window.NXSB && NXSB.sb;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  const lindoPeriodo = p => { const [a, m] = String(p).split('-'); return (MESES[+m - 1] || p) + ' ' + a; };
  const dinero = n => n == null ? '' : Number(n).toLocaleString('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 2 });
  let ov = null, ocupado = false, archivo = null;

  function estilo(){
    if (document.getElementById('nxpg-css')) return;
    const s = document.createElement('style'); s.id = 'nxpg-css';
    s.textContent = `#nxpg{position:fixed;inset:0;z-index:2147482500;background:radial-gradient(ellipse at 50% -10%,color-mix(in srgb,var(--ac,#8b5cf6) 20%,#0d0d14) 0%,#101016 42%,#070709 100%);color:#fff;overflow:auto;font-family:-apple-system,system-ui,sans-serif;padding:calc(env(safe-area-inset-top,0px) + 16px) 16px 40px}
    #nxpg h2{margin:0 0 4px;font-size:19px}#nxpg .sub{color:#9ca3af;font-size:13px;margin-bottom:14px;line-height:1.4}
    #nxpg input,#nxpg select{width:100%;box-sizing:border-box;margin:5px 0;padding:13px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:#fff;font-size:16px;-webkit-appearance:none;appearance:none;min-height:48px}
    #nxpg select option{color:#000}
    #nxpg button{width:100%;margin-top:8px;padding:14px;border-radius:12px;border:0;font-size:15px;font-weight:700;cursor:pointer}
    #nxpg .p{background:var(--ac,#8b5cf6);color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.3)}#nxpg .s{background:rgba(255,255,255,.08);color:#ddd}
    #nxpg .card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:18px;box-shadow:0 8px 28px rgba(0,0,0,.3);padding:14px;margin:12px 0}
    #nxpg .m{color:#9ca3af;font-size:12px}#nxpg .msg{font-size:13px;margin-top:8px;min-height:16px;color:#f87171}
    #nxpg .it{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;padding:10px 0;border-top:1px solid rgba(255,255,255,.08)}#nxpg .it:first-child{border-top:0}
    #nxpg .it button{width:auto;margin:0 0 0 6px;padding:8px 12px;font-size:13px}
    #nxpg .tag{font-size:11px;font-weight:800;padding:2px 8px;border-radius:20px;margin-left:6px}
    #nxpg .t-pendiente{background:rgba(251,191,36,.16);color:#fbbf24}#nxpg .t-acreditado{background:rgba(52,211,153,.16);color:#34d399}#nxpg .t-rechazado{background:rgba(248,113,113,.16);color:#f87171}
    #nxpg .arch{display:block;text-align:center;padding:14px;border:1.5px dashed rgba(255,255,255,.25);border-radius:12px;color:#d1d5db;font-size:14px;cursor:pointer;margin:6px 0}`;
    document.head.appendChild(s);
  }
  function cerrar(){ if (ov) { ov.remove(); ov = null; } archivo = null; }

  function periodos(){
    const out = [], h = new Date();
    for (let i = 0; i < 7; i++) { const d = new Date(h.getFullYear(), h.getMonth() - i, 1); out.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0')); }
    return out;
  }

  // Foto -> JPEG liviano (máx. 1600 px). PDF: se sube tal cual (máx. 2 MB).
  async function preparar(f){
    if (f.type === 'application/pdf') {
      if (f.size > 2 * 1024 * 1024) throw new Error('El PDF pesa más de 2 MB. Sacale una foto al comprobante o mandalo más liviano.');
      return { blob: f, ext: 'pdf', tipo: 'application/pdf' };
    }
    if (!/^image\//.test(f.type)) throw new Error('Elegí una foto o un PDF.');
    const url = URL.createObjectURL(f);
    try {
      const img = await new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ko(new Error('No se pudo leer la imagen. Probá con otra foto o con un PDF.')); i.src = url; });
      const k = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight)), w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
      const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.drawImage(img, 0, 0, w, h);
      let q = 0.72, blob = await new Promise(r => c.toBlob(r, 'image/jpeg', q));
      while (blob && blob.size > 1.8 * 1024 * 1024 && q > 0.3) { q -= 0.12; blob = await new Promise(r => c.toBlob(r, 'image/jpeg', q)); }
      if (!blob) throw new Error('No se pudo procesar la imagen.');
      return { blob, ext: 'jpg', tipo: 'image/jpeg' };
    } finally { URL.revokeObjectURL(url); }
  }

  async function abrir(){
    if (!sb() || !NXSB.perfil) { alert('Iniciá sesión para informar un pago'); return; }
    estilo(); cerrar();
    ov = document.createElement('div'); ov.id = 'nxpg';
    const ps = periodos();
    ov.innerHTML = `<button class="s" id="nxpg-x" style="width:auto;padding:8px 14px;margin:0 0 10px">← Volver</button>
      <h2>Informar un pago</h2><div class="sub">Mandale el comprobante a la administración. Solo lo ven ustedes dos y te avisamos cuando lo acrediten.</div>
      <div class="card" id="nxpg-e" style="display:none"></div>
      <div class="card" id="nxpg-f"><div class="m">Mes que pagás</div><select id="nxpg-p">${ps.map(p => `<option value="${p}">${lindoPeriodo(p)}</option>`).join('')}</select>
      <input id="nxpg-m" inputmode="decimal" placeholder="Monto pagado (opcional)" autocomplete="off">
      <input id="nxpg-n" placeholder="Nota (opcional)" maxlength="200" autocomplete="off">
      <label class="arch" id="nxpg-a">Adjuntar foto o PDF del comprobante<input id="nxpg-i" type="file" accept="image/*,application/pdf" style="display:none"></label>
      <div class="msg" id="nxpg-msg"></div><button class="p" id="nxpg-g">Enviar a la administración</button></div>
      <div class="card"><b>Mis comprobantes</b><div id="nxpg-l" class="m" style="margin-top:8px">Cargando…</div></div>`;
    document.body.appendChild(ov);
    document.getElementById('nxpg-x').onclick = cerrar;
    document.getElementById('nxpg-g').onclick = enviar;
    document.getElementById('nxpg-i').onchange = function(){
      archivo = this.files[0] || null;
      document.getElementById('nxpg-a').firstChild.textContent = archivo ? 'Adjunto: ' + archivo.name : 'Adjuntar foto o PDF del comprobante';
    };
    try {
      const { data } = await sb().from('barrios').select('comprobantes_activos').eq('id', NXSB.perfil.barrio_id).maybeSingle();
      if (data && data.comprobantes_activos === false) { document.getElementById('nxpg-f').innerHTML = '<div class="m" style="font-size:14px">Tu administración no está recibiendo comprobantes por la app. Consultale cómo informar tus pagos.</div>'; }
    } catch (e) {}
    estado();
    lista();
  }

  async function estado(){
    const el = document.getElementById('nxpg-e'); if (!el) return;
    try {
      const { data, error } = await sb().rpc('mi_estado_expensas');
      if (error || !data || !data.configurado) return;
      const ms = (data.meses || []).filter(m => Number(m.debe) > 0);
      el.style.display = 'block';
      if (!ms.length) { el.innerHTML = '<b style="color:#34d399">Estás al día con las expensas</b>'; return; }
      el.innerHTML = '<b style="color:#f87171">Tenés ' + ms.length + (ms.length === 1 ? ' mes pendiente' : ' meses pendientes') + '</b><div class="m" style="margin-top:6px">' + ms.map(m => esc(lindoPeriodo(m.periodo))).join(', ') + '</div><div class="m">Total: ' + esc(dinero(data.debe_total)) + '</div><div class="m" style="margin-top:6px">Si ya pagaste, informá el pago acá abajo.</div>';
    } catch (e) {}
  }

  async function enviar(){
    if (ocupado) return;
    const m = document.getElementById('nxpg-msg'); m.style.color = '#f87171'; m.textContent = '';
    if (!archivo) { m.textContent = 'Adjuntá la foto o el PDF del comprobante.'; return; }
    const txt = document.getElementById('nxpg-m').value.trim().replace(/\./g, '').replace(',', '.');
    const monto = txt === '' ? null : Number(txt);
    if (monto !== null && !(monto >= 0)) { m.textContent = 'El monto no es válido.'; return; }
    ocupado = true; const b = document.getElementById('nxpg-g'); b.disabled = true; b.textContent = 'Enviando…';
    let ruta = null;
    try {
      const pf = NXSB.perfil, a = await preparar(archivo);
      ruta = pf.barrio_id + '/' + pf.id + '/' + (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '' + Math.random().toString(16).slice(2)) + '.' + a.ext;
      const up = await sb().storage.from('comprobantes').upload(ruta, a.blob, { contentType: a.tipo, upsert: false });
      if (up.error) throw up.error;
      const { error } = await sb().from('comprobantes_pago').insert({ barrio_id: pf.barrio_id, propietario_id: pf.id, periodo: document.getElementById('nxpg-p').value,
        monto, nota: document.getElementById('nxpg-n').value.trim() || null, archivo: ruta, archivo_tipo: a.tipo });
      if (error) throw error;
      m.style.color = '#34d399'; m.textContent = 'Listo, la administración ya lo recibió.';
      archivo = null; document.getElementById('nxpg-i').value = ''; document.getElementById('nxpg-m').value = ''; document.getElementById('nxpg-n').value = '';
      document.getElementById('nxpg-a').firstChild.textContent = 'Adjuntar foto o PDF del comprobante';
      lista();
    } catch (e) {
      if (ruta) { try { await sb().storage.from('comprobantes').remove([ruta]); } catch (_) {} }
      m.textContent = (e && e.message) || 'No se pudo enviar. Probá de nuevo.';
    } finally { ocupado = false; b.disabled = false; b.textContent = 'Enviar a la administración'; }
  }

  async function ver(path){
    const w = window.open('', '_blank');
    const { data, error } = await sb().storage.from('comprobantes').createSignedUrl(path, 120);
    if (error || !data) { if (w) w.close(); alert('No se pudo abrir el comprobante.'); return; }
    if (w) w.location.href = data.signedUrl; else location.href = data.signedUrl;
  }

  async function lista(){
    const el = document.getElementById('nxpg-l'); if (!el) return;
    try {
      const { data, error } = await sb().from('comprobantes_pago').select('*').eq('propietario_id', NXSB.perfil.id).order('creado_en', { ascending: false }).limit(24);
      if (error) throw error;
      if (!data.length) { el.textContent = 'Todavía no informaste ningún pago.'; return; }
      const T = { pendiente: 'Pendiente', acreditado: 'Acreditado', rechazado: 'Observado' };
      el.innerHTML = data.map(r => `<div class="it"><div style="color:#fff"><b>${esc(lindoPeriodo(r.periodo))}</b><span class="tag t-${r.estado}">${T[r.estado]}</span>
        <div class="m">${r.monto != null ? esc(dinero(r.monto)) + ' · ' : ''}enviado el ${new Date(r.creado_en).toLocaleDateString('es-AR')}${r.origen === 'manual' ? ' · registrado por la administración' : ''}${r.archivo_borrado ? ' · archivo archivado' : ''}</div>
        ${r.estado === 'rechazado' && r.motivo ? `<div class="m" style="color:#fca5a5">Motivo: ${esc(r.motivo)}</div>` : ''}</div>
        <div style="white-space:nowrap">${r.archivo ? `<button class="s" data-v="${esc(r.archivo)}">Ver</button>` : ''}${r.estado === 'pendiente' ? `<button class="s" data-x="${r.id}" data-a="${esc(r.archivo || '')}">Quitar</button>` : ''}</div></div>`).join('');
      el.querySelectorAll('[data-v]').forEach(b => b.onclick = () => ver(b.dataset.v));
      el.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
        if (!confirm('¿Quitar este comprobante? La administración ya no lo va a ver.')) return;
        const { error: er } = await sb().from('comprobantes_pago').delete().eq('id', b.dataset.x);
        if (er) { alert('No se pudo quitar: ' + er.message); return; }
        if (b.dataset.a) { try { await sb().storage.from('comprobantes').remove([b.dataset.a]); } catch (_) {} }
        lista();
      });
    } catch (e) { el.textContent = 'No se pudieron cargar tus comprobantes.'; }
  }
  window.NXPagos = { abrir };
})();
