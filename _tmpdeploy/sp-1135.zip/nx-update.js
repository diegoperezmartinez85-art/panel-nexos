// Aviso de versión nueva: cuando se publica una actualización, muestra un cartel fijo para tocar y recargar.
(function(){
  'use strict';
  if (!('serviceWorker' in navigator)) return;
  const KEY = 'nx_ver_' + location.pathname;
  let habiaControl = !!navigator.serviceWorker.controller;
  function cartel(){
    if (document.getElementById('nx-upd')) return;
    const d = document.createElement('div'); d.id = 'nx-upd';
    d.style.cssText = 'position:fixed;left:8px;right:8px;top:calc(env(safe-area-inset-top,0px) + 12px);z-index:2147483600;background:#10b981;color:#052e22;font:700 15px -apple-system,system-ui,sans-serif;padding:14px 16px;border-radius:14px;text-align:center;box-shadow:0 6px 24px rgba(0,0,0,.5);cursor:pointer';
    d.innerHTML = '🔄 Hay una versión nueva<br><span style="font-weight:500;font-size:13px">Tocá acá para actualizar</span>';
    d.onclick = () => { try { if (window.__nxVer) localStorage.setItem(KEY, window.__nxVer); } catch (e) {}
      (window.caches ? caches.keys().then(ks => Promise.all(ks.map(k => caches.delete(k)))) : Promise.resolve()).catch(() => {}).then(() => location.reload()); };
    (document.body || document.documentElement).appendChild(d);
  }
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (habiaControl) cartel(); habiaControl = true; });
  function buscar(){ navigator.serviceWorker.getRegistration().then(r => { if (r) r.update().catch(() => {}); }).catch(() => {}); }
  // Las apps de administración no registraban el service worker: se registra acá para que se actualicen igual.
  if (!/nexos_control/.test(location.pathname)) navigator.serviceWorker.getRegistration().then(r => { if (!r) navigator.serviceWorker.register('sw.js').catch(() => {}); }).catch(() => {});
  // Compara la versión publicada con la que esta pantalla vio por última vez
  function verificarVersion(){
    fetch(/nexos_control/.test(location.pathname) ? 'sw_control.js' : 'sw.js', { cache: 'no-store' }).then(r => r.text()).then(t => {
      const m = /CACHE_NAME\s*=\s*'([^']+)'/.exec(t); if (!m) return; window.__nxVer = m[1];
      let vista = null; try { vista = localStorage.getItem(KEY); } catch (e) {}
      if (vista && vista !== m[1]) cartel(); else { try { localStorage.setItem(KEY, m[1]); } catch (e) {} }
    }).catch(() => {});
  }
  window.addEventListener('load', () => { setTimeout(buscar, 3000); setTimeout(verificarVersion, 1500); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { buscar(); verificarVersion(); } });
  setInterval(() => { buscar(); verificarVersion(); }, 5 * 60 * 1000);
})();
