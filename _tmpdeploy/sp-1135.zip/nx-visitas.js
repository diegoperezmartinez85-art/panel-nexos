// Vecino: pre-autorizar visitas con QR propio (reemplaza el formulario externo). Cada pase queda en Supabase y la garita lo valida.
(function(){
  'use strict';
  const sb = () => window.NXSB && NXSB.sb;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const hoyISO = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const fechaLinda = iso => iso.split('-').reverse().join('/');
  let ov = null;
  let cache = [];        // últimos pases del propietario (se muestra al instante y se refresca en segundo plano)
  let ocupado = false;   // evita doble toque
  let nuevoId = null;
  // Íconos de línea (sin emojis)
  const ICP = {
    ticket: '<path d="M3.5 8.5a2 2 0 0 0 2-2h13a2 2 0 0 0 2 2v2a1.5 1.5 0 0 0 0 3v2a2 2 0 0 0-2 2h-13a2 2 0 0 0-2-2v-2a1.5 1.5 0 0 0 0-3z"/><path d="M14.5 6.5v11" stroke-dasharray="1.6 2.2"/>',
    clip: '<path d="M20 11.5l-8.2 8.2a5 5 0 0 1-7.1-7.1l8.6-8.6a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l7.9-7.9"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
    share: '<path d="M12 14.5v-11M7.5 8 12 3.5 16.5 8M5 12.5v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    reloj: '<path d="M7 3.5h10M7 20.5h10M8.5 3.5v2.8l3.5 5.7 3.5-5.7V3.5M8.5 20.5v-2.8l3.5-5.7 3.5 5.7v2.8"/>',
    ok: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.3l2.4 2.4 4.6-4.9"/>',
    x: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    camara: '<path d="M4 8.5a2 2 0 0 1 2-2h2l1.5-2h5l1.5 2h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.5"/>'
  };
  const IC = (n, st) => '<svg class="nxi2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (st ? ' style="' + st + '"' : '') + '>' + ICP[n] + '</svg>';
  // Documentos de la visita (opcionales): DNI, registro y seguro
  const DOCS = [['dni', 'DNI'], ['registro', 'Registro'], ['seguro', 'Seguro']];
  const BUCKET = 'docs-visitas';
  let docsSel = {};      // { dni: {blob, url} | {path, url} }
  let seguroVence = '';

  // Achica la foto en el celular antes de subirla (~200 KB)
  function comprimir(file){
    return new Promise((res, rej) => {
      const u = URL.createObjectURL(file), im = new Image();
      im.onload = () => {
        const c = document.createElement('canvas'), x = c.getContext('2d');
        let lado = 1400, q = 0.72;
        const pasar = () => {
          const k = Math.min(1, lado / Math.max(im.width, im.height));
          c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
          x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0, c.width, c.height);
          c.toBlob(b => {
            if (!b) { URL.revokeObjectURL(u); rej(new Error('No se pudo procesar la foto')); return; }
            if (b.size > 450000 && lado > 700) { lado -= 250; q = Math.max(0.55, q - 0.06); pasar(); return; }
            URL.revokeObjectURL(u); res(b);
          }, 'image/jpeg', q);
        };
        pasar();
      };
      im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('No se pudo abrir la foto')); };
      im.src = u;
    });
  }
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));

  // Sube las fotos nuevas y devuelve { dni: ruta, ... } para guardar en el pase
  async function subirDocs(){
    const out = {};
    for (const [k] of DOCS) {
      const d = docsSel[k]; if (!d) continue;
      if (d.path) { out[k] = d.path; continue; }
      const path = NXSB.perfil.barrio_id + '/' + NXSB.perfil.id + '/' + uid() + '.jpg';
      const { error } = await sb().storage.from(BUCKET).upload(path, d.blob, { contentType: 'image/jpeg', upsert: false });
      if (error) throw new Error('No se pudo subir la foto del ' + k + ': ' + error.message);
      d.path = path; delete d.blob; out[k] = path;
    }
    if (out.seguro && seguroVence) out.seguro_vence = seguroVence;
    return out;
  }
  const cantDocs = d => DOCS.filter(([k]) => d && d[k]).length;

  async function urlsFirmadas(paths){
    const lista = paths.filter(Boolean); if (!lista.length) return {};
    const { data } = await sb().storage.from(BUCKET).createSignedUrls(lista, 600);
    const m = {}; (data || []).forEach(x => { if (x.signedUrl) m[x.path] = x.signedUrl; }); return m;
  }

  function pintarDocs(){
    const el = document.getElementById('nxv-docs'); if (!el) return;
    el.innerHTML = DOCS.map(([k, t]) => {
      const d = docsSel[k];
      return `<div class="doc" data-k="${k}">${d ? `<img src="${d.url || ''}" alt=""><button class="dx" data-q="${k}" aria-label="Quitar">${IC('x', 'pointer-events:none;width:14px;height:14px')}</button>` : '<span class="mas">' + IC('camara') + 'Agregar</span>'}<span class="dt">${t}</span></div>`;
    }).join('');
    el.querySelectorAll('.doc').forEach(t => t.onclick = e => {
      if (e.target.dataset.q) { e.stopPropagation(); delete docsSel[e.target.dataset.q]; if (e.target.dataset.q === 'seguro') seguroVence = ''; pintarDocs(); return; }
      const inp = document.getElementById('nxv-fi'); inp.dataset.k = t.dataset.k; inp.click();
    });
    const sv = document.getElementById('nxv-sv'); if (sv) sv.style.display = docsSel.seguro ? 'block' : 'none';
    const dc = document.getElementById('nxv-dc'); if (dc) dc.textContent = cantDocs(docsSel) ? '· ' + cantDocs(docsSel) + '/3' : '';
  }
  async function elegirFoto(inp){
    const f = inp.files && inp.files[0], k = inp.dataset.k; inp.value = ''; if (!f || !k) return;
    const el = document.querySelector('#nxv-docs .doc[data-k="' + k + '"]'); if (el) el.classList.add('cargando');
    try { const blob = await comprimir(f); docsSel[k] = { blob, url: URL.createObjectURL(blob) }; }
    catch (e) { alert(e.message); }
    pintarDocs();
  }
  async function cargarDocsDe(docs){
    docsSel = {}; seguroVence = (docs && docs.seguro_vence) || '';
    const m = await urlsFirmadas(DOCS.map(([k]) => docs && docs[k]));
    DOCS.forEach(([k]) => { if (docs && docs[k]) docsSel[k] = { path: docs[k], url: m[docs[k]] || '' }; });
    pintarDocs(); const sv = document.getElementById('nxv-svd'); if (sv) sv.value = seguroVence;
  }

  // Borra fotos de pases vencidos o usados hace más de un día (salvo las de visitas frecuentes)
  async function limpiarDocsViejos(){
    try {
      const lim = Date.now() - 24 * 3600 * 1000;
      const { data: ps } = await sb().from('visitas_qr').select('id,docs,valido_hasta,usado_en').eq('propietario_id', NXSB.perfil.id).neq('docs', '{}').limit(50);
      const viejos = (ps || []).filter(r => new Date(r.valido_hasta).getTime() < lim || (r.usado_en && new Date(r.usado_en).getTime() < lim));
      if (!viejos.length) return;
      const { data: fs } = await sb().from('visitas_frecuentes').select('docs').eq('propietario_id', NXSB.perfil.id);
      const enUso = new Set();
      (fs || []).forEach(v => DOCS.forEach(([k]) => v.docs && v.docs[k] && enUso.add(v.docs[k])));
      (ps || []).filter(r => !viejos.includes(r)).forEach(r => DOCS.forEach(([k]) => r.docs && r.docs[k] && enUso.add(r.docs[k])));
      const borrar = [];
      viejos.forEach(r => DOCS.forEach(([k]) => { const p = r.docs && r.docs[k]; if (p && !enUso.has(p)) borrar.push(p); }));
      if (borrar.length) await sb().storage.from(BUCKET).remove(borrar);
      for (const r of viejos) await sb().rpc('borrar_docs_pase', { p_id: r.id });
    } catch (e) {}
  }

  function estilo(){
    if (document.getElementById('nxv-css')) return;
    const s = document.createElement('style'); s.id = 'nxv-css';
    s.textContent = `#nxv{position:fixed;inset:0;z-index:2147482500;background:radial-gradient(ellipse at 50% -10%,color-mix(in srgb,var(--ac,#8b5cf6) 20%,#0d0d14) 0%,#101016 42%,#070709 100%);color:#fff;overflow:auto;font-family:-apple-system,system-ui,sans-serif;padding:16px;padding-top:calc(16px + env(safe-area-inset-top,0px));padding-bottom:calc(16px + env(safe-area-inset-bottom,0px));-webkit-overflow-scrolling:touch}
    #nxv h2{margin:0 0 4px;font-size:18px}#nxv .sub{color:#9ca3af;font-size:13px;margin-bottom:14px}
    #nxv input{width:100%;box-sizing:border-box;margin:5px 0;padding:13px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:#fff;font-size:16px}
    #nxv input[type=date]{-webkit-appearance:none;appearance:none;display:block;min-width:0;max-width:100%;text-align:left;line-height:1.2;min-height:48px}
    #nxv input[type=checkbox]{-webkit-appearance:none;appearance:none;width:24px!important;height:24px;min-width:24px;margin:0!important;padding:0;border-radius:8px;border:2px solid #52525b;background:#16161b;position:relative;flex:none;cursor:pointer}
    #nxv input[type=checkbox]:checked{background:var(--ac,#8b5cf6);border-color:var(--ac,#8b5cf6)}
    #nxv input[type=checkbox]:checked::after{content:'';position:absolute;left:7px;top:2px;width:6px;height:12px;border:solid #fff;border-width:0 2.5px 2.5px 0;transform:rotate(45deg)}
    #nxv button{width:100%;margin-top:8px;padding:14px;border-radius:12px;border:0;font-size:15px;font-weight:700;cursor:pointer}
    #nxv .p{background:var(--ac,#8b5cf6);color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.3)}#nxv .s{background:rgba(255,255,255,.08);color:#ddd}
    #nxv .card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:18px;box-shadow:0 8px 28px rgba(0,0,0,.3);padding:14px;margin:12px 0}
    #nxv .it{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 0;border-top:1px solid #2a2a31}#nxv .it:first-child{border-top:0}
    #nxv .it button{width:auto;margin:0;padding:8px 12px;font-size:13px}#nxv .m{color:#9ca3af;font-size:12px}
    #nxv .msg{font-size:13px;margin-top:8px;min-height:16px;color:#f87171}#nxv .qr{background:#fff;border-radius:16px;padding:14px;display:flex;justify-content:center;margin:12px 0}#nxv .qr img{width:100%;max-width:300px}
    #nxv .docs{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:8px}
    #nxv .doc{position:relative;aspect-ratio:5/4;border-radius:12px;border:1.5px dashed rgba(255,255,255,.22);background:rgba(255,255,255,.04);display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:pointer}
    #nxv .doc img{width:100%;height:100%;object-fit:cover}
    #nxv .doc .dt{position:absolute;left:0;right:0;bottom:0;padding:4px;font-size:11px;font-weight:700;text-align:center;background:rgba(0,0,0,.55);color:#fff}
    #nxv .doc .dx{position:absolute;top:4px;right:4px;width:24px!important;height:24px;margin:0!important;padding:0!important;border-radius:50%!important;background:rgba(0,0,0,.65)!important;color:#fff;font-size:12px!important;line-height:24px}
    #nxv .doc.cargando{opacity:.5}
    #nxv .nxi2{width:1.15em;height:1.15em;vertical-align:-.2em;flex:none}
    #nxv .doch{display:block;font-size:15px;font-weight:800;color:#f4f4f5;line-height:1.35}#nxv .doch .nxi2{margin-right:6px}
    #nxv .doc{border-color:color-mix(in srgb,var(--ac,#8b5cf6) 70%,transparent);background:color-mix(in srgb,var(--ac,#8b5cf6) 9%,transparent)}
    #nxv .doc .mas{display:flex;flex-direction:column;align-items:center;gap:3px;color:var(--ac,#a78bfa);font-size:11px;font-weight:800;margin-bottom:16px}#nxv .doc .mas .nxi2{width:30px;height:30px}`;
    document.head.appendChild(s);
  }
  function cerrar(){ if (ov) { ov.remove(); ov = null; } }

  async function abrir(){
    if (!sb() || !NXSB.perfil) { alert('Iniciá sesión para pre-autorizar visitas'); return; }
    estilo(); cerrar();
    ov = document.createElement('div'); ov.id = 'nxv';
    ov.innerHTML = `<button class="s" id="nxv-x" style="width:auto;padding:8px 14px;margin:0 0 10px">← Volver</button>
      <h2 style="display:flex;align-items:center;gap:8px">${IC('ticket')} Pre-autorizar visita</h2><div class="sub">Generá un pase QR para tu visita. Se lo mostrás o enviás y la garita lo valida.</div>
      <div class="card"><input id="nxv-n" placeholder="Nombre de la visita *" autocomplete="off"><input id="nxv-d" placeholder="DNI" inputmode="numeric" autocomplete="off">
      <input id="nxv-p" placeholder="Patente (si viene en vehículo)" autocapitalize="characters" autocomplete="off">
      <div class="m" style="margin-top:6px">Fecha de la visita</div><input id="nxv-f" type="date" value="${hoyISO()}" min="${hoyISO()}">
      <div class="m">Cargá al menos DNI o patente.</div>
      <div id="nxv-dd" style="margin-top:12px;border-top:1px solid #2a2a31;padding-top:12px"><div class="doch">${IC('clip')} Documentos de la visita <span class="m" style="font-weight:600">(opcional)</span> <span id="nxv-dc" class="m" style="font-weight:600"></span></div>
        <div class="m" style="margin-top:4px">Tocá un casillero para sacar o elegir la foto. La guardia las ve al escanear el QR y se borran solas cuando vence el pase.</div>
        <div class="docs" id="nxv-docs"></div>
        <div id="nxv-sv" style="display:none"><div class="m" style="margin-top:6px">Vencimiento del seguro (opcional)</div><input id="nxv-svd" type="date"></div>
        <input type="file" id="nxv-fi" accept="image/*" style="display:none">
      </div>
      <label class="m" style="display:flex;align-items:center;gap:8px;margin-top:8px"><input type="checkbox" id="nxv-fav" style="width:auto;margin:0"> ${IC('star')} Guardar como visita frecuente</label>
      <div class="msg" id="nxv-m"></div><button class="p" id="nxv-g">Generar pase QR</button></div>
      <div class="card" id="nxv-fc" style="display:none"><b style="display:flex;align-items:center;gap:7px">${IC('star')} Mis visitas frecuentes</b><div id="nxv-fl" style="margin-top:6px"></div></div>
      <div class="card"><b>Mis pases</b><div id="nxv-l" class="m" style="margin-top:8px">Cargando…</div></div>`;
    document.body.appendChild(ov);
    document.getElementById('nxv-x').onclick = cerrar;
    document.getElementById('nxv-g').onclick = generar;
    docsSel = {}; seguroVence = ''; pintarDocs();
    document.getElementById('nxv-fi').onchange = e => elegirFoto(e.target);
    document.getElementById('nxv-svd').onchange = e => { seguroVence = e.target.value; };
    lista(); frecuentes(); limpiarDocsViejos();
  }

  // ¿ya hay un pase pendiente igual (misma persona y mismo día)?
  function duplicado(nombre, dni, pat, f){
    const n = String(nombre).trim().toLowerCase();
    return cache.find(r => !r.usado_en && new Date(r.valido_hasta) > new Date() && hoyISOde(r.valido_hasta) === f &&
      ((dni && r.dni === dni) || (pat && r.patente === pat) || String(r.visitante).trim().toLowerCase() === n));
  }

  async function crearPase(nombre, dni, pat, f, m, docs){
    if (ocupado) return null;
    // Antes de crear, refrescamos la lista real para no duplicar
    try { const { data } = await sb().from('visitas_qr').select('*').eq('propietario_id', NXSB.perfil.id).order('valido_desde', { ascending: false }).limit(30); if (data) cache = data; } catch (e) {}
    const dup = duplicado(nombre, dni, pat, f);
    if (dup) {
      const ver = confirm('Ya tenés un pase pendiente para ' + dup.visitante + ' el ' + fechaLinda(f) + '.\n\nAceptar = ver ese pase.\nCancelar = no hacer nada.');
      if (ver) { mostrarQR(dup); }
      if (m) m.textContent = 'Ya existe un pase pendiente para esa visita en esa fecha.';
      return null;
    }
    ocupado = true;
    try { return await crearPase2(nombre, dni, pat, f, m, docs); } finally { ocupado = false; }
  }

  async function crearPase2(nombre, dni, pat, f, m, docs){
    const [y, mo, d] = f.split('-').map(Number);
    const desde = new Date(y, mo - 1, d, 0, 0, 0), hasta = new Date(y, mo - 1, d, 23, 59, 59);
    const { data, error } = await sb().from('visitas_qr').insert({
      barrio_id: NXSB.perfil.barrio_id, propietario_id: NXSB.perfil.id, visitante: nombre, dni: dni || null, patente: pat || null,
      mza: NXSB.perfil.mza || null, casa: NXSB.perfil.casa || null, valido_desde: desde.toISOString(), valido_hasta: hasta.toISOString(),
      docs: docs || {}
    }).select().single();
    if (error) { if (m) m.textContent = 'No se pudo crear el pase: ' + error.message; return null; }
    cache = [data, ...cache.filter(x => x.id !== data.id)]; nuevoId = data.id;
    return data;
  }

  async function generar(){
    const m = document.getElementById('nxv-m'); m.textContent = '';
    const nombre = document.getElementById('nxv-n').value.trim(), dni = document.getElementById('nxv-d').value.replace(/\D/g, ''),
      pat = document.getElementById('nxv-p').value.trim().toUpperCase().replace(/[^A-Z0-9]/g, ''), f = document.getElementById('nxv-f').value;
    if (!nombre) { m.textContent = 'Poné el nombre de la visita'; return; }
    if (!dni && !pat) { m.textContent = 'Cargá el DNI o la patente'; return; }
    if (!f || f < hoyISO()) { m.textContent = 'Elegí una fecha válida'; return; }
    const b = document.getElementById('nxv-g'); b.disabled = true; b.textContent = 'Generando…';
    let docs = {};
    if (cantDocs(docsSel)) {
      b.textContent = 'Subiendo fotos…';
      try { docs = await subirDocs(); } catch (e) { m.textContent = e.message; b.disabled = false; b.textContent = 'Generar pase QR'; return; }
      b.textContent = 'Generando…';
    }
    const data = await crearPase(nombre, dni, pat, f, m, docs);
    b.disabled = false; b.textContent = 'Generar pase QR';
    if (!data) return;
    const fav = document.getElementById('nxv-fav');
    if (fav && fav.checked) {
      const { error } = await sb().from('visitas_frecuentes').insert({ barrio_id: NXSB.perfil.barrio_id, propietario_id: NXSB.perfil.id, nombre, dni: dni || null, patente: pat || null, docs });
      if (error) alert('El pase se creó, pero no se pudo guardar como frecuente: ' + error.message);
    }
    docsSel = {}; seguroVence = '';
    mostrarQR(data);
  }

  async function frecuentes(){
    const { data, error } = await sb().from('visitas_frecuentes').select('*').eq('propietario_id', NXSB.perfil.id).order('nombre');
    const card = document.getElementById('nxv-fc'), el = document.getElementById('nxv-fl'); if (!card || !el) return;
    if (error || !data || !data.length) { card.style.display = 'none'; return; }
    card.style.display = 'block';
    el.innerHTML = data.map(v => `<div class="it"><div><b>${esc(v.nombre)}</b><div class="m">${v.patente ? esc(v.patente) : ''}${v.patente && v.dni ? ' · ' : ''}${v.dni ? 'DNI ' + esc(v.dni) : ''}${cantDocs(v.docs) ? ' · ' + IC('clip') + ' ' + cantDocs(v.docs) : ''}</div></div>
      <span><button class="p" data-h="${v.id}">Pase hoy</button> <button class="s" data-e="${v.id}">Otro día</button> <button class="s" data-x="${v.id}" aria-label="Quitar">${IC('x', 'pointer-events:none')}</button></span></div>`).join('');
    el.querySelectorAll('[data-h]').forEach(b => b.onclick = async () => {
      const v = data.find(x => x.id === b.dataset.h); b.disabled = true; b.textContent = '…';
      const m = document.getElementById('nxv-m'); if (m) m.textContent = '';
      const r = await crearPase(v.nombre, v.dni, v.patente, hoyISO(), m, v.docs || {});
      if (r) mostrarQR(r); else { b.disabled = false; b.textContent = 'Pase hoy'; if (m && m.textContent) alert(m.textContent); }
    });
    el.querySelectorAll('[data-e]').forEach(b => b.onclick = () => {
      const v = data.find(x => x.id === b.dataset.e);
      document.getElementById('nxv-n').value = v.nombre; document.getElementById('nxv-d').value = v.dni || ''; document.getElementById('nxv-p').value = v.patente || '';
      if (cantDocs(v.docs)) cargarDocsDe(v.docs);
      const f = document.getElementById('nxv-f'); f.focus(); f.scrollIntoView({ block: 'center' });
    });
    el.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => { if (!confirm('¿Sacar de tus frecuentes?')) return; await sb().from('visitas_frecuentes').delete().eq('id', b.dataset.x); frecuentes(); });
  }

  // El generador de QR falla con letras acentuadas o ñ ("code length overflow"): se pasan a letras simples.
  const plano = t => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, '');
  function textoQR(r){
    const f = r.valido_hasta ? hoyISOde(r.valido_hasta) : hoyISO();
    return plano('INGRESO NEXOS\nVisita: ' + r.visitante + '\nPatente: ' + (r.patente || '') + '\nDNI: ' + (r.dni || '') + '\nMza:' + (r.mza || '') + ' Casa:' + (r.casa || '') + '\nFecha: ' + f + '\nPase: ' + r.codigo);
  }
  function hoyISOde(iso){ const d = new Date(iso); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

  // El QR se dibuja con borde blanco (zona de silencio). Sin ese borde, al mostrarlo sobre
  // fondo oscuro (visor de WhatsApp, modo oscuro) la cámara de la garita no lo puede leer.
  function dibujar(texto, codigo){
    return new Promise(res => {
      const div = document.createElement('div'); div.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(div);
      new QRCode(div, { text: texto, width: 400, height: 400, correctLevel: QRCode.CorrectLevel.M });
      setTimeout(() => {
        const fuente = div.querySelector('canvas') || div.querySelector('img');
        const armar = () => {
          const Q = 400, M = 48, T = codigo ? 56 : 0;
          const c = document.createElement('canvas'); c.width = Q + 2 * M; c.height = Q + 2 * M + T;
          const x = c.getContext('2d'); x.fillStyle = '#ffffff'; x.fillRect(0, 0, c.width, c.height);
          x.imageSmoothingEnabled = false; x.drawImage(fuente, M, M, Q, Q);
          if (codigo) { x.fillStyle = '#111111'; x.font = 'bold 30px -apple-system, system-ui, sans-serif'; x.textAlign = 'center'; x.fillText('Código: ' + codigo, c.width / 2, Q + M + 38); }
          div.remove(); res(c.toDataURL('image/png'));
        };
        if (fuente && fuente.tagName === 'IMG' && !fuente.complete) fuente.onload = armar; else if (fuente) armar(); else { div.remove(); res(''); }
      }, 150);
    });
  }

  async function mostrarQR(r){
    if (typeof QRCode === 'undefined') { alert('No se pudo cargar el generador de QR. Revisá tu conexión.'); return; }
    const url = await dibujar(textoQR(r), r.codigo);
    const fecha = fechaLinda(hoyISOde(r.valido_hasta));
    ov.innerHTML = `<button class="s" id="nxv-x" style="width:auto;padding:8px 14px;margin:0 0 10px">← Volver</button>
      <h2>Pase de acceso</h2>${r.id === nuevoId ? '<div style="background:#14532d;color:#bbf7d0;border-radius:10px;padding:8px 12px;font-size:13px;font-weight:700;margin-bottom:8px;display:flex;align-items:center;gap:6px">' + IC('check') + ' Pase guardado correctamente</div>' : ''}<div class="sub">${esc(r.visitante)} · Válido el ${fecha}</div>
      <div class="qr"><img src="${url}" alt="QR"></div>
      <div class="m" style="text-align:center">Código: <b>${esc(r.codigo)}</b> · Mza ${esc(r.mza || '-')} Casa ${esc(r.casa || '-')}</div>${cantDocs(r.docs) ? `<div class="m" style="text-align:center;margin-top:4px;color:#86efac">${IC('clip')} ${DOCS.filter(([k]) => r.docs[k]).map(([, t]) => t).join(', ')} adjunto${cantDocs(r.docs) > 1 ? 's' : ''} — la guardia los ve al escanear</div>` : ''}
      <button class="p" id="nxv-s" style="display:flex;align-items:center;justify-content:center;gap:8px">${IC('share')} Compartir pase</button><button class="s" id="nxv-o">Listo</button>`;
    document.getElementById('nxv-x').onclick = abrir; document.getElementById('nxv-o').onclick = cerrar;
    document.getElementById('nxv-s').onclick = async () => {
      const msg = 'Pase de ingreso — Nexos\nHola ' + r.visitante + ', este es tu pase para el ' + fecha + '. Mostralo en la garita.\nCódigo: ' + r.codigo;
      try {
        const blob = await (await fetch(url)).blob(); const file = new File([blob], 'pase-nexos.png', { type: 'image/png' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], text: msg }); return; }
      } catch (e) { if (e && e.name === 'AbortError') return; }
      window.open('https://wa.me/?text=' + encodeURIComponent(msg), '_blank');
    };
  }

  function pintarLista(){
    const el = document.getElementById('nxv-l'); if (!el) return;
    const data = cache;
    if (!data.length) { el.textContent = 'Todavía no creaste pases.'; return; }
    el.innerHTML = data.map(r => {
      const venc = new Date(r.valido_hasta) < new Date();
      const est = r.usado_en ? IC('ok', 'color:#4ade80') + ' Usado' : venc ? IC('reloj', 'color:#f87171') + ' Vencido' : IC('reloj', 'color:#fbbf24') + ' Pendiente';
      const nuevo = r.id === nuevoId ? ' <span style="background:#22c55e;color:#000;border-radius:8px;padding:1px 7px;font-size:11px;font-weight:800">' + IC('check', 'width:11px;height:11px') + ' Guardado</span>' : '';
      return `<div class="it"><div><b>${esc(r.visitante)}</b>${nuevo}<div class="m">${fechaLinda(hoyISOde(r.valido_hasta))} · ${est}</div></div>${!r.usado_en && !venc ? `<span><button class="s" data-v="${r.id}">Ver QR</button> <button class="s" data-c="${r.id}" aria-label="Cancelar">${IC('x', 'pointer-events:none')}</button></span>` : ''}</div>`;
    }).join('');
    el.querySelectorAll('[data-v]').forEach(b => b.onclick = () => mostrarQR(cache.find(x => x.id === b.dataset.v)));
    el.querySelectorAll('[data-c]').forEach(b => b.onclick = async () => { if (!confirm('¿Cancelar este pase?')) return; cache = cache.filter(x => x.id !== b.dataset.c); pintarLista(); await sb().from('visitas_qr').delete().eq('id', b.dataset.c); lista(); });
  }

  async function lista(){
    pintarLista();   // al instante, con lo que ya sabemos
    const { data, error } = await sb().from('visitas_qr').select('*').eq('propietario_id', NXSB.perfil.id).order('valido_desde', { ascending: false }).limit(30);
    const el = document.getElementById('nxv-l'); if (!el) return;
    if (error) { if (!cache.length) el.textContent = 'No se pudieron cargar: ' + error.message; return; }
    cache = data; pintarLista();
  }

  window.abrirInvitaciones = abrir;
  window.cerrarInvitaciones = cerrar;
})();
