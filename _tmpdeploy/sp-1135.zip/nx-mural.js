// Mural de novedades + avisos push para el vecino
(function(){
  const VAPID='BD2jYgNAut8wRhE6YJ_0X74tgSPbkHjOCAUUp9c53_vb80GgDGX7XFBPzNRpS-NRg8npMnFcvPGcAyHnV4k_u5Y';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const k=()=>'nx_mural_visto_'+(NXSB.perfil&&NXSB.perfil.id);
  let lista=[],ui=false;
  const b64=s=>{const p='='.repeat((4-s.length%4)%4),r=atob((s+p).replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from([...r].map(c=>c.charCodeAt(0)));};
  function css(){const st=document.createElement('style');st.textContent=`
  #nxm-bar{position:fixed;top:calc(12px + env(safe-area-inset-top,0px));left:12px;display:flex;gap:8px;z-index:9000}
  #nxm-bar button{position:relative;width:42px;height:42px;border-radius:50%;border:1px solid #333;background:#1a1a1f;color:#fff;font-size:19px}
  #nxm-dot{position:absolute;top:-2px;right:-2px;min-width:16px;height:16px;border-radius:8px;background:#ef4444;font-size:10px;line-height:16px;font-weight:800;display:none}
  #nxm-ov{position:fixed;inset:0;background:#0f0f11;z-index:9500;display:none;overflow:auto;padding:16px;padding-top:calc(16px + env(safe-area-inset-top,0px));color:#fff;font-family:-apple-system,system-ui,sans-serif}
  #nxm-ov .c{background:#1a1a1f;border:1px solid #2c2c33;border-radius:14px;padding:14px;margin-bottom:12px}
  #nxm-ov .m{color:#9aa0a6;font-size:12px}`;document.head.appendChild(st);}
  function montar(){
    if(ui)return;ui=true;css();
    const bar=document.createElement('div');bar.id='nxm-bar';
    bar.innerHTML='<button id="nxm-b1" title="Novedades">📢<span id="nxm-dot"></span></button><button id="nxm-b2" title="Avisos" style="display:none">🔔</button>';
    document.body.appendChild(bar);
    const ov=document.createElement('div');ov.id='nxm-ov';
    ov.innerHTML='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px"><b style="letter-spacing:2px">📢 NOVEDADES DEL BARRIO</b><button id="nxm-x" style="background:#2a2a31;color:#fff;border:0;border-radius:8px;padding:8px 14px;font-size:15px">Cerrar</button></div><div id="nxm-ban" style="display:none;background:#3b2a05;border:1px solid #f59e0b;border-radius:14px;padding:14px;margin-bottom:14px"><div style="font-weight:700;margin-bottom:6px">🔔 Activá las notificaciones</div><div class="m" style="margin-bottom:10px;color:#e5c07b">Así te avisamos de las novedades del barrio aunque tengas la app cerrada.</div><button id="nxm-act" style="width:100%;padding:13px;border:0;border-radius:10px;background:#f59e0b;color:#241600;font-weight:800;font-size:16px">Activar notificaciones</button></div><div id="nxm-l"></div>';
    document.body.appendChild(ov);
    document.getElementById('nxm-b1').onclick=abrir;
    document.getElementById('nxm-x').onclick=()=>{ov.style.display='none';};
    document.getElementById('nxm-b2').onclick=activarPush;document.getElementById('nxm-act').onclick=activarPush;
    if('serviceWorker' in navigator){navigator.serviceWorker.register('./sw.js',{scope:'./'}).catch(e=>console.warn('sw',e));}
    pushEstado();
  }
  function pintar(){
    const visto=+(localStorage.getItem(k())||0);
    const nuevos=lista.filter(c=>new Date(c.creado_en).getTime()>visto).length;
    const d=document.getElementById('nxm-dot');d.style.display=nuevos?'block':'none';d.textContent=nuevos;
    document.getElementById('nxm-l').innerHTML=lista.length?lista.map(c=>`<div class="c"><b>${esc(c.titulo)}</b><div class="m">${new Date(c.creado_en).toLocaleString('es-AR',{dateStyle:'short',timeStyle:'short'})}</div>${c.foto?`<img src="${esc(c.foto)}" data-nxfoto="1" style="cursor:pointer;display:block;margin-top:10px;width:100%;max-height:340px;object-fit:cover;border-radius:12px">`:''}<div style="margin-top:6px;white-space:pre-wrap;font-size:15px">${esc(c.cuerpo)}</div></div>`).join(''):'<div class="m">Todavía no hay novedades</div>';
    document.querySelectorAll('#nxm-l img[data-nxfoto]').forEach(im=>im.onclick=()=>{if(window.nxVerFoto)window.nxVerFoto(im.src);});
  }
  function abrir(){document.getElementById('nxm-ov').style.display='block';localStorage.setItem(k(),Date.now());pintar();}
  async function cargar(forzar){
    lista=await (window.nxTraerComunicados?window.nxTraerComunicados(forzar):NXSB.sb.from('comunicados').select('id,titulo,cuerpo,creado_en,foto').order('creado_en',{ascending:false}).limit(20).then(r=>r.data||[]));pintar();
  }
  async function pushEstado(){
    try{
      if(!('serviceWorker' in navigator)||!('PushManager' in window))return;
      const reg=await navigator.serviceWorker.ready;const s=await reg.pushManager.getSubscription();
      const b=document.getElementById('nxm-b2');
      const ban=document.getElementById('nxm-ban');if(Notification.permission==='granted'&&s){await guardar(s);b.style.display='none';ban.style.display='none';}else{b.style.display='block';ban.style.display='block';}
    }catch(e){}
  }
  async function guardar(sub){
    const j=sub.toJSON();
    const {error}=await NXSB.sb.from('push_suscripciones').upsert({endpoint:j.endpoint,p256dh:j.keys.p256dh,auth:j.keys.auth,perfil_id:NXSB.perfil.id,barrio_id:NXSB.perfil.barrio_id},{onConflict:'endpoint'});
    if(error)NXSB.aviso('No se pudo guardar el aviso: '+error.message);
  }
  async function activarPush(){
    try{
      const p=await Notification.requestPermission();
      if(p!=='granted'){NXSB.aviso('No diste permiso para notificaciones');return;}
      const reg=await navigator.serviceWorker.ready;
      const viejo=await reg.pushManager.getSubscription();if(viejo){try{await viejo.unsubscribe();}catch(e){}}
      const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64(VAPID)});
      await guardar(sub);document.getElementById('nxm-b2').style.display='none';document.getElementById('nxm-ban').style.display='none';
      NXSB.aviso('🔔 Avisos activados','#10b981');
    }catch(e){NXSB.aviso('No se pudo activar: '+e.message+' (en iPhone la app debe estar agregada a la pantalla de inicio)');}
  }
  let bloqueado=false;
  async function chequearBloqueo(){
    try{
      const {data,error}=await NXSB.sb.rpc('mi_bloqueo'); if(error||!data)return;
      if(data.bloqueado){bloqueado=true;if(typeof mostrarPantallaBaneado==='function')mostrarPantallaBaneado({motivo:data.motivo});}
      else if(bloqueado){bloqueado=false;if(typeof mostrarPantallaPanico==='function')mostrarPantallaPanico();const nb=document.getElementById('app-nav-bar');if(nb)nb.style.display='';const fb=document.getElementById('settings-floating-btn');if(fb)fb.style.display='';}
    }catch(e){}
  }
  window.NXMural={chequearBloqueo,iniciar:async function(){
    montar();await cargar();chequearBloqueo();
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)chequearBloqueo();});
    setInterval(()=>{if(!document.hidden)chequearBloqueo();},180000);
    NXSB.sb.channel('comunicados-vecino').on('postgres_changes',{event:'*',schema:'public',table:'comunicados'},()=>cargar(true)).subscribe();
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)cargar();});
  }};
})();
