// ── NEXOS SERVICE WORKER ─────────────────────────────────
// ⚠️ Cambiar este número CADA VEZ que subas un HTML nuevo
const CACHE_NAME = 'prueba-nexos-v1.135';

const ARCHIVOS = [
  './nexos_panico.html',
  './manifest.json',
  './icon-192.png',
  './supabase.js',
  './nx-supabase.js',
  './nx-mural.js',
  './nx-update.js',
  './nx-instalar.js',
  './nx-visitas.js',
  './nx-vacia.js',
  './nx-pagos.js',
  './nx-vecino.js',
  './nx-iconos.js',
  './icon-512.png','./icono-vecino-192.png','./icono-vecino-512.png'
];

// ── INSTALACIÓN ───────────────────────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache =>
      cache.addAll(ARCHIVOS).catch(() =>
        cache.addAll(['./nexos_panico.html', './manifest.json'])
      )
    )
  );
  self.skipWaiting(); // activa el SW nuevo sin esperar que cierren la pestaña
});

// ── ACTIVACIÓN: limpia cachés viejas ─────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k.startsWith('prueba-nexos-v') && k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim()) // toma control de todas las pestañas abiertas
  );
});

// ── FETCH ─────────────────────────────────────────────────

// Safari no acepta respuestas con redirección servidas por un service worker
// (p. ej. Cloudflare Pages redirige /x.html a /x). Se reconstruye sin el flag.
async function limpiarRedireccion(res) {
  if (!res || !res.redirected) return res;
  const body = await res.clone().blob();
  return new Response(body, { status: res.status, statusText: res.statusText, headers: res.headers });
}

self.addEventListener('fetch', event => {
  if (event.request.url.includes('script.google.com')) return;
  // Datos de Supabase (API, realtime, auth): SIEMPRE a la red, nunca desde caché (si no, las listas quedan congeladas)
  { const u = new URL(event.request.url); if (event.request.method !== 'GET' || u.hostname.endsWith('.supabase.co') || u.hostname.endsWith('.supabase.in')) return; }

  const esHTML = event.request.destination === 'document' ||
                 event.request.url.endsWith('.html');

  if (esHTML) {
    // HTML: cache first → respuesta instantánea, actualiza en background
    event.respondWith(
      caches.match(event.request).then(cached => {
        const network = fetch(event.request).then(limpiarRedireccion).then(response => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        }).catch(() => null);
        return cached ? limpiarRedireccion(cached) : network;
      })
    );
  } else {
    // Resto (iconos, manifest): cache first → actualiza en background
    event.respondWith(
      caches.match(event.request).then(cached => {
        const network = fetch(event.request).then(limpiarRedireccion).then(response => {
          if (response && response.status === 200 && response.type !== 'opaque') {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        }).catch(() => null);
        return cached ? limpiarRedireccion(cached) : network;
      })
    );
  }
});

// ── PUSH (novedades del barrio) ───────────────────────────
self.addEventListener('push', event => {
  if (!event.data) return;
  let d = {};
  try { d = event.data.json(); } catch { d.title = event.data.text(); }
  event.waitUntil(self.registration.showNotification(d.title || 'NEXOS', {
    body: d.body || '', icon: './icon-192.png', badge: './icon-192.png', tag: 'nexos-novedad'
  }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window' }).then(cs => {
    for (const c of cs) { if (c.url.includes('nexos_panico') && 'focus' in c) return c.focus(); }
    return self.clients.openWindow('./nexos_panico.html');
  }));
});
