// NEXOS — adaptador Supabase (entorno de pruebas)
// Usa SOLO la clave pública (publishable). La seguridad real está en las políticas RLS del servidor.
(function(){
  const URL_ = 'https://ylrjlkdgsmyhoaunsizr.supabase.co';
  const KEY_ = 'sb_publishable_NatKMoTk3xnJmihbvgXSoA_tUDfBv9t';
  const sb = window.supabase.createClient(URL_, KEY_, {
    auth: { persistSession: true, autoRefreshToken: true, storageKey: 'nx_sb_auth' }
  });
  const NXSB = { sb, perfil: null };
  window.NXSB = NXSB;

  const css = `
  #nxsb-login{position:fixed;inset:0;z-index:2147483000;background:#0f0f11;display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,system-ui,sans-serif;color:#fff}
  #nxsb-login .c{width:100%;max-width:340px;text-align:center}
  #nxsb-login h1{font-size:22px;letter-spacing:3px;margin:0 0 4px}
  #nxsb-login p{color:#9aa0a6;font-size:13px;margin:0 0 22px}
  #nxsb-login input{width:100%;box-sizing:border-box;padding:14px;margin-bottom:10px;border-radius:12px;border:1px solid #333;background:#1a1a1f;color:#fff;font-size:16px}
  #nxsb-login button{width:100%;padding:14px;border:0;border-radius:12px;background:var(--nxc,#06b6d4);color:var(--nxt,#00222b);font-weight:700;font-size:16px}
  #nxsb-login .e{color:#ef4444;font-size:13px;min-height:18px;margin-top:10px}
  
  #nxsb-cc{position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.8);display:flex;align-items:center;justify-content:center;padding:16px;font-family:-apple-system,system-ui,sans-serif}
  #nxsb-cc div{background:#1b1b20;color:#fff;border:1px solid #333;border-radius:16px;padding:20px;width:100%;max-width:340px}
  #nxsb-cc h3{margin:0 0 12px}#nxsb-cc input{width:100%;box-sizing:border-box;margin:5px 0;padding:12px;border-radius:10px;border:1px solid #444;background:#0f0f12;color:#fff;font-size:16px}
  #nxsb-cc button{width:100%;margin-top:8px;padding:12px;border-radius:10px;border:0;font-size:15px;font-weight:700}
  #nxsb-cc .ok{background:#8b5cf6;color:#fff}#nxsb-cc .no{background:#333;color:#ccc}#nxsb-cc p{font-size:13px;margin:8px 0 0;min-height:16px}
  #nxsb-gear{position:fixed;top:calc(env(safe-area-inset-top,0px) + 6px);right:6px;z-index:2147482000;width:30px;height:30px;border-radius:15px;border:1px solid #444;background:rgba(20,20,24,.55);color:#ddd;font-size:15px;line-height:28px;text-align:center;padding:0;opacity:.55}
  #nxsb-gear i{position:absolute;right:-1px;top:-1px;width:9px;height:9px;border-radius:5px;background:#f59e0b}
  #nxsb-menu{position:fixed;top:calc(env(safe-area-inset-top,0px) + 42px);right:6px;z-index:2147482001;background:#1b1b20;color:#fff;border:1px solid #333;border-radius:12px;padding:6px;min-width:210px;font:14px -apple-system,system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.5)}
  #nxsb-menu div,#nxsb-menu button{display:block;width:100%;text-align:left;background:none;border:0;color:#fff;padding:10px 12px;font-size:14px;border-radius:8px}
  #nxsb-menu .st{color:#9aa0a6;font-size:12px}#nxsb-menu button:active{background:#2a2a30}`;
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  const IC = {"gear": "<path d=\"M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm88-29.84q.06-2.16,0-4.32l14.92-18.64a8,8,0,0,0,1.48-7.06,107.21,107.21,0,0,0-10.88-26.25,8,8,0,0,0-6-3.93l-23.72-2.64q-1.48-1.56-3-3L186,40.54a8,8,0,0,0-3.94-6,107.71,107.71,0,0,0-26.25-10.87,8,8,0,0,0-7.06,1.49L130.16,40Q128,40,125.84,40L107.2,25.11a8,8,0,0,0-7.06-1.48A107.6,107.6,0,0,0,73.89,34.51a8,8,0,0,0-3.93,6L67.32,64.27q-1.56,1.49-3,3L40.54,70a8,8,0,0,0-6,3.94,107.71,107.71,0,0,0-10.87,26.25,8,8,0,0,0,1.49,7.06L40,125.84Q40,128,40,130.16L25.11,148.8a8,8,0,0,0-1.48,7.06,107.21,107.21,0,0,0,10.88,26.25,8,8,0,0,0,6,3.93l23.72,2.64q1.49,1.56,3,3L70,215.46a8,8,0,0,0,3.94,6,107.71,107.71,0,0,0,26.25,10.87,8,8,0,0,0,7.06-1.49L125.84,216q2.16.06,4.32,0l18.64,14.92a8,8,0,0,0,7.06,1.48,107.21,107.21,0,0,0,26.25-10.88,8,8,0,0,0,3.93-6l2.64-23.72q1.56-1.48,3-3L215.46,186a8,8,0,0,0,6-3.94,107.71,107.71,0,0,0,10.87-26.25,8,8,0,0,0-1.49-7.06Zm-16.1-6.5a73.93,73.93,0,0,1,0,8.68,8,8,0,0,0,1.74,5.48l14.19,17.73a91.57,91.57,0,0,1-6.23,15L187,173.11a8,8,0,0,0-5.1,2.64,74.11,74.11,0,0,1-6.14,6.14,8,8,0,0,0-2.64,5.1l-2.51,22.58a91.32,91.32,0,0,1-15,6.23l-17.74-14.19a8,8,0,0,0-5-1.75h-.48a73.93,73.93,0,0,1-8.68,0,8,8,0,0,0-5.48,1.74L100.45,215.8a91.57,91.57,0,0,1-15-6.23L82.89,187a8,8,0,0,0-2.64-5.1,74.11,74.11,0,0,1-6.14-6.14,8,8,0,0,0-5.1-2.64L46.43,170.6a91.32,91.32,0,0,1-6.23-15l14.19-17.74a8,8,0,0,0,1.74-5.48,73.93,73.93,0,0,1,0-8.68,8,8,0,0,0-1.74-5.48L40.2,100.45a91.57,91.57,0,0,1,6.23-15L69,82.89a8,8,0,0,0,5.1-2.64,74.11,74.11,0,0,1,6.14-6.14A8,8,0,0,0,82.89,69L85.4,46.43a91.32,91.32,0,0,1,15-6.23l17.74,14.19a8,8,0,0,0,5.48,1.74,73.93,73.93,0,0,1,8.68,0,8,8,0,0,0,5.48-1.74L155.55,40.2a91.57,91.57,0,0,1,15,6.23L173.11,69a8,8,0,0,0,2.64,5.1,74.11,74.11,0,0,1,6.14,6.14,8,8,0,0,0,5.1,2.64l22.58,2.51a91.32,91.32,0,0,1,6.23,15l-14.19,17.74A8,8,0,0,0,199.87,123.66Z\"/>", "key": "<path d=\"M216.57,39.43A80,80,0,0,0,83.91,120.78L28.69,176A15.86,15.86,0,0,0,24,187.31V216a16,16,0,0,0,16,16H72a8,8,0,0,0,8-8V208H96a8,8,0,0,0,8-8V184h16a8,8,0,0,0,5.66-2.34l9.56-9.57A79.73,79.73,0,0,0,160,176h.1A80,80,0,0,0,216.57,39.43ZM224,98.1c-1.09,34.09-29.75,61.86-63.89,61.9H160a63.7,63.7,0,0,1-23.65-4.51,8,8,0,0,0-8.84,1.68L116.69,168H96a8,8,0,0,0-8,8v16H72a8,8,0,0,0-8,8v16H40V187.31l58.83-58.82a8,8,0,0,0,1.68-8.84A63.72,63.72,0,0,1,96,95.92c0-34.14,27.81-62.8,61.9-63.89A64,64,0,0,1,224,98.1ZM192,76a12,12,0,1,1-12-12A12,12,0,0,1,192,76Z\"/>", "out": "<path d=\"M120,216a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H56V208h56A8,8,0,0,1,120,216Zm109.66-93.66-40-40a8,8,0,0,0-11.32,11.32L204.69,120H112a8,8,0,0,0,0,16h92.69l-26.35,26.34a8,8,0,0,0,11.32,11.32l40-40A8,8,0,0,0,229.66,122.34Z\"/>", "dot": "<path d=\"M232,128A104,104,0,1,1,128,24,104.13,104.13,0,0,1,232,128Z\"/>", "warn": "<path d=\"M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z\"/>"};
  const ico = (n, c) => '<svg viewBox="0 0 256 256" fill="' + (c || 'currentColor') + '" width="18" height="18" style="vertical-align:-4px;margin-right:8px;flex-shrink:0" aria-hidden="true">' + IC[n] + '</svg>';
  NXSB.confirmar = function(titulo, texto, okTxt, onOk){
    if (document.getElementById('nxsb-conf')) return;
    const d = document.createElement('div'); d.id = 'nxsb-conf';
    d.style.cssText = 'position:fixed;inset:0;z-index:2147483100;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:20px;font-family:-apple-system,system-ui,sans-serif';
    d.innerHTML = '<div style="background:#1b1b20;color:#fff;border:1px solid #333;border-radius:20px;padding:22px;width:100%;max-width:330px;text-align:center"><div style="font-size:19px;font-weight:800;margin-bottom:8px">' + titulo + '</div><div style="font-size:14px;color:#a8adbb;line-height:1.45;margin-bottom:18px">' + texto + '</div><button id="nxsb-conf-ok" style="width:100%;padding:14px;border:0;border-radius:14px;background:linear-gradient(135deg,#f25a5a,#d62f2f);color:#fff;font-size:15px;font-weight:800;margin-bottom:8px">' + okTxt + '</button><button id="nxsb-conf-no" style="width:100%;padding:14px;border:1px solid #3a3a42;border-radius:14px;background:transparent;color:#cfd2dc;font-size:15px;font-weight:700">Cancelar</button></div>';
    document.body.appendChild(d);
    d.querySelector('#nxsb-conf-no').onclick = () => d.remove();
    d.addEventListener('click', e => { if (e.target === d) d.remove(); });
    d.querySelector('#nxsb-conf-ok').onclick = () => { d.remove(); onOk(); };
  };
  NXSB.aviso = function(msg, color){
    let a = document.getElementById('nxsb-aviso');
    if (!a){ a = document.createElement('div'); a.id='nxsb-aviso';
      a.style.cssText='position:fixed;left:8px;right:8px;top:calc(env(safe-area-inset-top,0px) + 8px);z-index:2147483200;padding:10px 12px;border-radius:10px;font:13px -apple-system,system-ui,sans-serif;color:#fff;text-align:center';
      document.body.appendChild(a); }
    a.style.background = color || '#b91c1c'; a.textContent = msg; a.style.display='block';
    clearTimeout(a._t); a._t = setTimeout(()=>{ a.style.display='none'; }, 8000);
  };
  function ojo(inp){
    const w = document.createElement('div'); w.style.cssText = 'position:relative';
    inp.parentNode.insertBefore(w, inp); w.appendChild(inp); inp.style.paddingRight = '48px';
    const b = document.createElement('button'); b.type = 'button'; b.textContent = '👁'; b.setAttribute('aria-label','Mostrar contraseña');
    b.style.cssText = 'position:absolute;right:6px;top:6px;width:38px;height:38px;padding:0;background:transparent;color:#9aa0a6;font-size:18px;border:0;border-radius:8px';
    b.onclick = () => { const v = inp.type === 'password'; inp.type = v ? 'text' : 'password'; b.style.opacity = v ? '1' : '.6'; b.textContent = v ? '🙈' : '👁'; };
    w.appendChild(b);
  }
  function ui(){
    let o = document.getElementById('nxsb-login');
    if (o) return o;
    o = document.createElement('div'); o.id = 'nxsb-login';
    o.style.setProperty('--nxc', window.NXSB_COLOR||'#06b6d4'); o.style.setProperty('--nxt', window.NXSB_COLOR_TXT||'#00222b'); o.innerHTML = `<div class="c"><img src="${window.NXSB_LOGO||'icon-192.png'}" width="84" height="84" style="border-radius:20px;margin-bottom:14px"><h1>NEXOS</h1><div style="color:${window.NXSB_COLOR||'#06b6d4'};font-weight:700;letter-spacing:2px;font-size:13px;margin-bottom:6px">${window.NXSB_TITULO||''}</div><p id="nxsb-sub">${window.NXSB_SUB||'Ingresá con tu usuario'}</p>
      <input id="nxsb-mail" type="email" placeholder="Email" autocomplete="username" autocapitalize="none">
      <input id="nxsb-pass" type="password" placeholder="Contraseña" autocomplete="current-password">
      <button id="nxsb-go">Ingresar</button><div class="e" id="nxsb-err"></div></div>`;
    document.body.appendChild(o);
    const go = async () => {
      const err = document.getElementById('nxsb-err'); err.textContent = '';
      const email = document.getElementById('nxsb-mail').value.trim();
      const password = document.getElementById('nxsb-pass').value;
      if (!email || !password) { err.textContent = 'Completá email y contraseña'; return; }
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) { err.textContent = 'Email o contraseña incorrectos'; return; }
      arrancar();
    };
    document.getElementById('nxsb-go').onclick = go;
    ojo(document.getElementById('nxsb-pass'));
    {
      const c = o.querySelector('.c');
      const fg = document.createElement('div');
      fg.style.cssText = 'margin-top:14px;font-size:13px;color:#9aa0a6;text-decoration:underline';
      fg.textContent = 'Olvidé mi contraseña';
      c.appendChild(fg);
      fg.onclick = () => {
        c.innerHTML = `<img src="${window.NXSB_LOGO||'icon-192.png'}" width="72" height="72" style="border-radius:18px;margin-bottom:10px"><h1>NUEVA CONTRASEÑA</h1><p>Pedile un código de recuperación a la administración y usalo acá</p>
          <input id="nxsb-fmail" type="email" placeholder="Tu email" autocapitalize="none">
          <input id="nxsb-fcod" placeholder="Código de recuperación" autocapitalize="characters" autocomplete="off">
          <input id="nxsb-fpass" type="password" placeholder="Contraseña nueva (mínimo 8 caracteres)" autocomplete="new-password">
          <button id="nxsb-fgo">Cambiar contraseña</button><div class="e" id="nxsb-ferr"></div>
          <div id="nxsb-fback" style="margin-top:16px;font-size:13px;color:#9aa0a6;text-decoration:underline">Volver</div>`;
        ojo(document.getElementById('nxsb-fpass'));
        document.getElementById('nxsb-fback').onclick = () => { o.remove(); ui(); };
        document.getElementById('nxsb-fgo').onclick = async () => {
          const e = document.getElementById('nxsb-ferr'); e.textContent = '';
          const email = document.getElementById('nxsb-fmail').value, codigo = document.getElementById('nxsb-fcod').value, password = document.getElementById('nxsb-fpass').value;
          const r = await fetch(URL_ + '/functions/v1/restablecer-clave', { method:'POST', headers:{ 'Content-Type':'application/json', apikey: KEY_ }, body: JSON.stringify({ codigo, email, password }) }).then(x => x.json()).catch(() => ({ error:'Sin conexión' }));
          if (!r.ok) { e.textContent = r.error || 'No se pudo cambiar la contraseña'; return; }
          const { error } = await sb.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
          if (error) { e.textContent = 'Contraseña cambiada. Ingresá con tu email y la nueva contraseña.'; return; }
          arrancar();
        };
      };
    }
    if (window.NXSB_REGISTRO) {
      const c = o.querySelector('.c');
      const lk = document.createElement('div');
      lk.style.cssText = 'margin-top:16px;font-size:13px;color:#9aa0a6;text-decoration:underline';
      lk.textContent = 'Tengo un código de invitación';
      c.appendChild(lk);
      lk.onclick = () => {
        c.innerHTML = `<img src="${window.NXSB_LOGO||'icon-192.png'}" width="72" height="72" style="border-radius:18px;margin-bottom:10px"><h1>CREAR MI CUENTA</h1><p>Usá el código que te dio la administración</p>
          <input id="nxsb-cod" placeholder="Código de invitación" autocapitalize="characters" autocomplete="off">
          <input id="nxsb-rmail" type="email" placeholder="Tu email" autocapitalize="none">
          <input id="nxsb-rpass" type="password" placeholder="Contraseña (mínimo 8 caracteres)" autocomplete="new-password">
          <button id="nxsb-rgo">Crear cuenta</button><div class="e" id="nxsb-rerr"></div>
          <div id="nxsb-back" style="margin-top:16px;font-size:13px;color:#9aa0a6;text-decoration:underline">Volver</div>`;
        ojo(document.getElementById('nxsb-rpass'));
        document.getElementById('nxsb-back').onclick = () => { o.remove(); ui(); };
        document.getElementById('nxsb-rgo').onclick = async () => {
          const e = document.getElementById('nxsb-rerr'); e.textContent = '';
          const codigo = document.getElementById('nxsb-cod').value, email = document.getElementById('nxsb-rmail').value, password = document.getElementById('nxsb-rpass').value;
          const r = await fetch(URL_ + '/functions/v1/canjear-invitacion', { method:'POST', headers:{ 'Content-Type':'application/json', apikey: KEY_ }, body: JSON.stringify({ codigo, email, password }) }).then(x => x.json()).catch(() => ({ error:'Sin conexión' }));
          if (!r.ok) { e.textContent = r.error || 'No se pudo crear la cuenta'; return; }
          const { error } = await sb.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
          if (error) { e.textContent = 'Cuenta creada. Ingresá con tu email y contraseña.'; return; }
          arrancar();
        };
      };
    }
    document.getElementById('nxsb-pass').addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    const m = localStorage.getItem('nx_sb_mail'); if (m) document.getElementById('nxsb-mail').value = m;
    return o;
  }

  async function cargarPerfil(){
    const { data: u } = await sb.auth.getUser();
    if (!u || !u.user) return null;
    const { data, error } = await sb.from('perfiles').select('*').eq('id', u.user.id).maybeSingle();
    if (error || !data || !data.activo) return null;
    NXSB.perfil = data; return data;
  }


  // ===== Términos y Política de Privacidad (se piden una vez por versión del texto) =====
  const TYC_VERSION = '2026-10-28';
  function tycTexto(rol){
    const comun = `
      <h3>1. Qué es Nexos</h3>
      <p>Nexos es una aplicación para barrios privados que permite registrar ingresos, pre-autorizar visitas, enviar alertas de emergencia, comunicarse con la administración y la garita, reservar espacios comunes y gestionar avisos de la comunidad.</p>
      <h3>2. Quién es responsable de tus datos</h3>
      <p>La administración de tu barrio decide para qué se usan los datos de la comunidad y es la responsable de su tratamiento. Nexos provee y mantiene la herramienta y trata los datos únicamente por cuenta del barrio, siguiendo sus instrucciones y para las finalidades descriptas aquí.</p>
      <h3>3. Qué datos se tratan</h3>
      <p>Tu nombre, correo electrónico, teléfono, manzana y casa; los datos de las visitas que registrás o que ingresan a tu casa (nombre, DNI, patente); los registros de ingreso y egreso; las reservas; las fotos y datos de tus mascotas; los avisos de casa vacía; y, solo cuando accionás una alerta de pánico, tu ubicación aproximada en ese momento. También se guardan datos técnicos mínimos del dispositivo, necesarios para enviarte notificaciones.</p>
      <h3>4. Para qué se usan</h3>
      <p>Exclusivamente para la seguridad y el funcionamiento del barrio: controlar accesos, avisar a la garita y a los vecinos cuando corresponde, atender emergencias y comunicar novedades. Los datos no se venden, no se ceden a terceros ajenos al barrio ni se usan con fines publicitarios.</p>
      <h3>5. Tus derechos</h3>
      <p>Conforme a la Ley 25.326 de Protección de los Datos Personales, podés acceder a tus datos, rectificarlos, actualizarlos y solicitar su supresión, dirigiéndote a la administración de tu barrio o a los canales de soporte de Nexos. La Agencia de Acceso a la Información Pública, como órgano de control de la Ley 25.326, tiene la atribución de atender las denuncias y reclamos de quienes vean afectados sus derechos.</p>
      <h3>6. Seguridad</h3>
      <p>Los datos viajan cifrados, cada persona accede solo a lo que su rol permite y la información de un barrio está aislada de la de los demás. Aun así, ningún sistema es infalible: cuidá tu clave, no la compartas y cerrá sesión en dispositivos que no sean tuyos.</p>
      <h3>7. Ubicación y notificaciones</h3>
      <p>La ubicación se usa solo al activar una alerta de emergencia, para que la garita pueda asistirte. Las notificaciones requieren tu permiso y podés desactivarlas desde el dispositivo, sabiendo que podrías no recibir avisos importantes.</p>
      <h3>8. Conservación</h3>
      <p>Los datos se conservan mientras seas usuario del barrio y durante los plazos que el barrio defina para sus registros de seguridad. Al darte de baja, tus datos personales se eliminan o anonimizan, salvo los que deban conservarse por una obligación legal o para la defensa de derechos.</p>
      <h3>9. Uso responsable</h3>
      <p>Te comprometés a usar Nexos de buena fe: no activar falsas alarmas, no registrar datos de terceros sin motivo legítimo, no compartir tu cuenta y no usar la información de otros vecinos para fines ajenos al barrio. El barrio podrá aplicar las medidas previstas en su reglamento ante un uso indebido.</p>
      <h3>10. Alcance del servicio</h3>
      <p>Nexos es una herramienta de apoyo a la seguridad y la convivencia. No reemplaza a los servicios públicos de emergencia (911, bomberos, ambulancia) ni garantiza un funcionamiento ininterrumpido, ya que depende de la conexión a internet, del dispositivo y de las notificaciones del sistema operativo. En una emergencia grave, comunicate siempre también por los medios habituales.</p>`;
    const guardia = `
      <h3>Deber de reserva (personal de garita)</h3>
      <p>Los datos que ves como parte de tu tarea (residentes, visitas, patentes, DNI, alertas, casas vacías, mascotas) son confidenciales. Solo podés usarlos para controlar accesos y atender la seguridad del barrio. No los fotografíes, copies, difundas ni compartas con terceros, ni durante ni después de tu relación con el barrio. El acceso con tu usuario queda registrado.</p>`;
    const admin = `
      <h3>Responsabilidades de la administración</h3>
      <p>Como administrador cargás y gestionás datos de la comunidad. Te comprometés a hacerlo solo con motivo legítimo, a informar a los vecinos sobre el uso de la aplicación, a dar de baja los accesos de quienes ya no correspondan y a atender los pedidos de acceso, rectificación o supresión de datos. Sos responsable de los usuarios y permisos que habilites, y de que el personal a tu cargo conozca y respete el deber de reserva.</p>`;
    const cierre = `
      <h3>Cambios y contacto</h3>
      <p>Si estos textos cambian, se te pedirá aceptar la nueva versión para seguir usando la aplicación. Para consultas o para ejercer tus derechos, comunicate con la administración de tu barrio o con el soporte de Nexos.</p>
      <p style="color:#8e94ab;font-size:12px">Versión ${TYC_VERSION} · Ley 25.326 (Argentina)</p>`;
    return comun + (rol === 'garita' ? guardia : '') + ((rol === 'admin_barrio' || rol === 'admin_general') ? admin : '') + cierre;
  }
  async function exigirTerminos(p){
    const k = 'nx_tyc_' + p.id;
    try { if (localStorage.getItem(k) === TYC_VERSION) return true; } catch (e) {}
    try {
      const { data } = await sb.from('aceptaciones').select('id').eq('perfil_id', p.id).eq('version', TYC_VERSION).maybeSingle();
      if (data) { try { localStorage.setItem(k, TYC_VERSION); } catch (e) {} return true; }
    } catch (e) {}
    return new Promise(resolve => {
      const ov = document.createElement('div'); ov.id = 'nxsb-tyc';
      ov.style.cssText = 'position:fixed;inset:0;z-index:2147483100;background:radial-gradient(ellipse at 50% -10%,#241a52 0%,#0b0c11 60%);display:flex;align-items:center;justify-content:center;padding:14px;font-family:-apple-system,system-ui,sans-serif;color:#eef0f7';
      ov.innerHTML = '<div style="width:100%;max-width:460px;max-height:100%;display:flex;flex-direction:column;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.12);border-radius:22px;padding:18px;box-sizing:border-box">'
        + '<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px"><img src="' + (window.NXSB_LOGO || 'icon-192.png') + '" width="44" height="44" style="border-radius:12px"><div><div style="font-size:19px;font-weight:800">Antes de empezar</div><div style="font-size:13px;color:#8e94ab">Términos y Política de Privacidad</div></div></div>'
        + '<div id="nxsb-tyc-t" style="flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;font-size:13.5px;line-height:1.5;color:#c9cde0;padding-right:6px;border-top:1px solid rgba(255,255,255,.08);border-bottom:1px solid rgba(255,255,255,.08)"><style>#nxsb-tyc-t h3{font-size:14px;color:#fff;margin:14px 0 4px}#nxsb-tyc-t p{margin:0 0 6px}</style>' + tycTexto(p.rol) + '</div>'
        + '<label style="display:flex;gap:10px;align-items:flex-start;margin:14px 0 10px;font-size:14px;line-height:1.35;cursor:pointer"><input id="nxsb-tyc-c" type="checkbox" style="width:22px;height:22px;margin:0;flex-shrink:0;accent-color:#7c5cff"><span>Leí y acepto los Términos y Condiciones y la Política de Privacidad.</span></label>'
        + '<div id="nxsb-tyc-m" style="color:#ff8a8a;font-size:13px;min-height:16px;margin-bottom:6px"></div>'
        + '<button id="nxsb-tyc-ok" disabled style="width:100%;padding:14px;border:0;border-radius:14px;background:linear-gradient(135deg,#7c5cff,#5b3df5);color:#fff;font-weight:700;font-size:16px;opacity:.45">Aceptar y continuar</button>'
        + '<button id="nxsb-tyc-no" style="margin-top:8px;background:none;border:0;color:#8e94ab;text-decoration:underline;font-size:13px">No acepto, salir</button></div>';
      document.body.appendChild(ov);
      const chk = ov.querySelector('#nxsb-tyc-c'), ok = ov.querySelector('#nxsb-tyc-ok'), msg = ov.querySelector('#nxsb-tyc-m');
      chk.onchange = () => { ok.disabled = !chk.checked; ok.style.opacity = chk.checked ? '1' : '.45'; };
      ov.querySelector('#nxsb-tyc-no').onclick = async () => { await sb.auth.signOut(); location.reload(); };
      ok.onclick = async () => {
        ok.disabled = true; ok.textContent = 'Guardando…'; msg.textContent = '';
        const { error } = await sb.from('aceptaciones').upsert({ perfil_id: p.id, barrio_id: p.barrio_id || null, version: TYC_VERSION, rol: p.rol, app: location.pathname.split('/').pop() || 'index', dispositivo: (navigator.userAgent || '').slice(0, 290) }, { onConflict: 'perfil_id,version', ignoreDuplicates: true });
        if (error) { msg.textContent = 'No se pudo guardar tu aceptación. Revisá tu conexión y probá de nuevo.'; ok.disabled = false; ok.textContent = 'Aceptar y continuar'; return; }
        try { localStorage.setItem(k, TYC_VERSION); } catch (e) {}
        ov.remove(); resolve(true);
      };
    });
  }


  // ===== Verificación en dos pasos (solo superusuario): app de códigos TOTP =====
  function mfaPantalla(html){
    let o = document.getElementById('nxsb-mfa'); if (o) o.remove();
    o = document.createElement('div'); o.id = 'nxsb-mfa';
    o.style.cssText = 'position:fixed;inset:0;z-index:2147483300;background:#0b0c11;display:flex;align-items:center;justify-content:center;padding:22px;font-family:-apple-system,system-ui,sans-serif;color:#eceef6;overflow:auto';
    o.innerHTML = '<div style="width:100%;max-width:340px;text-align:center"><img src="' + (window.NXSB_LOGO||'icon-192.png') + '" width="64" height="64" style="border-radius:16px;margin-bottom:12px">' + html + '</div>';
    document.body.appendChild(o);
    o.querySelectorAll('input').forEach(i => { i.style.cssText = 'width:100%;box-sizing:border-box;padding:14px;margin:12px 0 4px;border-radius:12px;border:1px solid #333;background:#15161c;color:#fff;font-size:22px;letter-spacing:8px;text-align:center'; });
    o.querySelectorAll('button.p').forEach(b => { b.style.cssText = 'width:100%;padding:14px;margin-top:10px;border:0;border-radius:12px;background:linear-gradient(135deg,#7c5cff,#5b3df5);color:#fff;font-weight:700;font-size:16px'; });
    o.querySelectorAll('.lk').forEach(b => { b.style.cssText = 'margin-top:16px;font-size:13px;color:#9aa0a6;text-decoration:underline;background:none;border:0'; });
    return o;
  }
  const soloDigitos = i => i.addEventListener('input', () => { i.value = i.value.replace(/\D/g, '').slice(0, 6); });
  function mfaPedirCodigo(){
    return new Promise(res => {
      const o = mfaPantalla('<h2 style="margin:0 0 6px;font-size:22px">Verificación en dos pasos</h2><p style="margin:0;color:#9aa0a6;font-size:14px">Abrí tu app de códigos e ingresá el número de 6 dígitos de <b>Nexos</b>.</p><input id="nxmfa-c" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000"><div id="nxmfa-e" style="min-height:20px;color:#f87171;font-size:13px;margin-top:6px"></div><button class="p" id="nxmfa-ok">Verificar</button><button class="lk" id="nxmfa-out">Salir</button>');
      const inp = o.querySelector('#nxmfa-c'), err = o.querySelector('#nxmfa-e'); soloDigitos(inp); setTimeout(() => inp.focus(), 50);
      const ir = async () => {
        err.textContent = ''; if (inp.value.length !== 6) { err.textContent = 'Ingresá los 6 dígitos'; return; }
        const { data: f, error: e1 } = await sb.auth.mfa.listFactors();
        const fac = f && (f.totp || [])[0]; if (e1 || !fac) { err.textContent = 'No se encontró tu verificación. Probá de nuevo.'; return; }
        const { error } = await sb.auth.mfa.challengeAndVerify({ factorId: fac.id, code: inp.value });
        if (error) { err.textContent = /rate|too many/i.test(error.message) ? 'Demasiados intentos. Esperá un minuto.' : 'Código incorrecto o vencido. Probá con el siguiente.'; inp.value = ''; return; }
        o.remove(); res(true);
      };
      o.querySelector('#nxmfa-ok').onclick = ir; inp.addEventListener('keydown', e => { if (e.key === 'Enter') ir(); });
      o.querySelector('#nxmfa-out').onclick = async () => { await sb.auth.signOut(); location.reload(); };
    });
  }
  async function mfaActivar(){
    // Limpia intentos viejos que quedaron sin terminar
    try { const { data: all } = await sb.auth.mfa.listFactors(); for (const f of ((all && all.all) || [])) if (f.status === 'unverified') await sb.auth.mfa.unenroll({ factorId: f.id }); } catch (e) {}
    const { data, error } = await sb.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'Nexos ' + new Date().toISOString().slice(0, 16) });
    if (error || !data) { NXSB.aviso('No se pudo iniciar la verificación en dos pasos: ' + ((error && error.message) || 'error')); return false; }
    return new Promise(res => {
      const o = mfaPantalla('<h2 style="margin:0 0 6px;font-size:22px">Activá la verificación en dos pasos</h2><p style="margin:0 0 12px;color:#9aa0a6;font-size:14px">Protege tu cuenta de superusuario. Cada vez que entres vas a necesitar un código de tu celular.</p>'
        + '<ol style="text-align:left;color:#cfd3e4;font-size:14px;line-height:1.5;padding-left:20px;margin:0 0 12px"><li>Instalá una app de códigos (Google Authenticator, Microsoft Authenticator, Authy o 1Password).</li><li>Escaneá este código QR desde la app.</li><li>Ingresá el número de 6 dígitos que muestre.</li></ol>'
        + '<img src="' + data.totp.qr_code + '" alt="Código QR" style="width:200px;height:200px;background:#fff;border-radius:12px;padding:8px"><div style="font-size:12px;color:#9aa0a6;margin-top:8px">¿No podés escanear? Ingresá esta clave a mano:</div><div style="font-family:ui-monospace,Menlo,monospace;font-size:13px;word-break:break-all;color:#22d3ee;margin-top:4px;user-select:all">' + data.totp.secret + '</div>'
        + '<input id="nxmfa-c" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000"><div id="nxmfa-e" style="min-height:20px;color:#f87171;font-size:13px;margin-top:6px"></div><button class="p" id="nxmfa-ok">Activar</button><button class="lk" id="nxmfa-skip">Ahora no</button>');
      const inp = o.querySelector('#nxmfa-c'), err = o.querySelector('#nxmfa-e'); soloDigitos(inp);
      const ir = async () => {
        err.textContent = ''; if (inp.value.length !== 6) { err.textContent = 'Ingresá los 6 dígitos'; return; }
        const { error: e2 } = await sb.auth.mfa.challengeAndVerify({ factorId: data.id, code: inp.value });
        if (e2) { err.textContent = 'Código incorrecto. Revisá que sea el de Nexos y probá con el siguiente.'; inp.value = ''; return; }
        o.remove(); NXSB.aviso('Verificación en dos pasos activada', '#047857'); res(true);
      };
      o.querySelector('#nxmfa-ok').onclick = ir; inp.addEventListener('keydown', e => { if (e.key === 'Enter') ir(); });
      o.querySelector('#nxmfa-skip').onclick = async () => { try { await sb.auth.mfa.unenroll({ factorId: data.id }); } catch (e) {} o.remove(); res(false); };
    });
  }
  async function exigirMFA(){
    try {
      const { data: a, error } = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
      if (error || !a) return;
      if (a.nextLevel === 'aal2' && a.currentLevel !== 'aal2') await mfaPedirCodigo();
      else if (a.nextLevel === 'aal1') await mfaActivar();
    } catch (e) { console.warn('mfa', e); }
  }

  async function arrancar(){
    const ses = (await sb.auth.getSession()).data.session;
    const rolesOk = window.NXSB_ROLES || [];
    let p = ses ? await cargarPerfil() : null;
    if (p && rolesOk.length && !rolesOk.includes(p.rol)) {
      await sb.auth.signOut();
      ui(); document.getElementById('nxsb-err').textContent = 'Este usuario no tiene acceso a esta app'; return;
    }
    if (!p) { ui(); return; }
    if (p.rol !== 'admin_general') {
      const { data: susp } = await sb.rpc('barrio_suspendido');
      if (susp) {
        // No se cierra la sesión: queda esta pantalla y, apenas Nexos reactiva el barrio, la app se abre sola.
        const s = document.createElement('div'); s.id = 'nxsb-susp';
        s.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:#0b0c11;display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,system-ui,sans-serif;color:#eceef6;text-align:center';
        s.innerHTML = '<div style="max-width:320px"><img src="' + (window.NXSB_LOGO||'icon-192.png') + '" width="72" height="72" style="border-radius:18px;margin-bottom:16px"><h2 style="margin:0 0 8px;font-size:22px">Barrio suspendido</h2><p style="color:#8e94ab;margin:0 0 20px;line-height:1.5">El acceso de este barrio está pausado. Cuando Nexos lo reactive, esta pantalla se actualiza sola.</p><button id="nxsb-reint" style="width:100%;padding:14px;border:0;border-radius:14px;background:linear-gradient(135deg,#7c5cff,#5b3df5);color:#fff;font-weight:700;font-size:16px">Reintentar</button><button id="nxsb-susp-salir" style="margin-top:12px;background:none;border:0;color:#8e94ab;text-decoration:underline;font-size:14px">Salir</button></div>';
        document.body.appendChild(s);
        const chequear = async () => { try { const { data } = await sb.rpc('barrio_suspendido'); if (!data) location.reload(); } catch (e) {} };
        document.getElementById('nxsb-reint').onclick = chequear;
        document.getElementById('nxsb-susp-salir').onclick = async () => { await sb.auth.signOut(); location.reload(); };
        setInterval(chequear, 20000);
        document.addEventListener('visibilitychange', () => { if (!document.hidden) chequear(); });
        return;
      }
    }
    if (p.rol === 'admin_general') await exigirMFA();
    await exigirTerminos(p);
    localStorage.setItem('nx_sb_mail', (ses.user.email || ''));
    const o = document.getElementById('nxsb-login'); if (o) o.remove();
    if (!window.NXSB_SIN_GEAR && !document.getElementById('nxsb-gear')) {
      const g = document.createElement('button'); g.id = 'nxsb-gear'; g.innerHTML = '<svg viewBox="0 0 256 256" fill="currentColor" width="18" height="18" style="vertical-align:-4px" aria-hidden="true">' + IC.gear + '</svg><i></i>';
      g.onclick = () => {
        const m0 = document.getElementById('nxsb-menu'); if (m0) { m0.remove(); return; }
        const m = document.createElement('div'); m.id = 'nxsb-menu';
        m.innerHTML = '<div class="st">' + (p.nombre||'') + '</div><div class="st" id="nxsb-rt">' + (NXSB._rt||'') + '</div><button id="nxsb-m-clave">' + ico('key') + 'Cambiar mi clave</button><button id="nxsb-m-salir" style="color:#ff8a8a">' + ico('out') + 'Salir</button>';
        document.body.appendChild(m);
        m.querySelector('#nxsb-m-clave').onclick = () => { m.remove(); NXSB.cambiarClave(); };
        m.querySelector('#nxsb-m-salir').onclick = () => { m.remove(); NXSB.confirmar('¿Cerrar sesión?', 'Vas a salir de tu cuenta en este dispositivo. Para volver a entrar vas a necesitar tu clave.', 'Sí, salir', NXSB.salir); };
        setTimeout(() => document.addEventListener('click', function cerrar(e){ if (!m.contains(e.target) && e.target.id !== 'nxsb-gear') { m.remove(); document.removeEventListener('click', cerrar); } }), 0);
      };
      document.body.appendChild(g);
    }
    if (typeof window.NXSB_alIngresar === 'function') window.NXSB_alIngresar(p);
  }

  NXSB.salir = async function(){ await sb.auth.signOut(); localStorage.removeItem('nx_manzana'); localStorage.removeItem('nx_casa'); location.reload(); };
  NXSB.cambiarClave = function(){
    if (document.getElementById('nxsb-cc')) return;
    const d = document.createElement('div'); d.id = 'nxsb-cc';
    d.innerHTML = '<div><h3>Cambiar mi clave</h3><input id="cc1" type="password" placeholder="Clave actual" autocomplete="current-password"><input id="cc2" type="password" placeholder="Clave nueva (mínimo 8)" autocomplete="new-password"><input id="cc3" type="password" placeholder="Repetir clave nueva" autocomplete="new-password"><p id="cc-m"></p><button class="ok" id="cc-ok">Guardar</button><button class="no" id="cc-no">Cancelar</button></div>';
    document.body.appendChild(d);
    const m = t => { document.getElementById('cc-m').textContent = t; };
    document.getElementById('cc-no').onclick = () => d.remove();
    document.getElementById('cc-ok').onclick = async () => {
      const a = document.getElementById('cc1').value, n = document.getElementById('cc2').value, r = document.getElementById('cc3').value;
      if (!a) return m('Poné tu clave actual');
      if (n.length < 8) return m('La clave nueva debe tener al menos 8 caracteres');
      if (n !== r) return m('Las claves nuevas no coinciden');
      if (n === a) return m('La clave nueva debe ser distinta');
      m('Guardando…');
      const mail = (await sb.auth.getUser()).data.user.email;
      const v = await sb.auth.signInWithPassword({ email: mail, password: a });
      if (v.error) return m('La clave actual no es correcta');
      const u = await sb.auth.updateUser({ password: n });
      if (u.error) return m('No se pudo cambiar: ' + u.error.message);
      m('✅ Clave cambiada'); setTimeout(() => d.remove(), 1500);
    };
  };

  // ── VECINO: enviar pánico ─────────────────────────────
  // Devuelve true si se guardó en el servidor. El servidor completa casa/barrio/hora (no se confía en el cliente).
  NXSB.enviarPanico = async function(payload){
    const { error } = await sb.from('panicos').insert({
      tipo: payload.tipo || 'emergencia',
      lat: payload.lat, lng: payload.lng, maps_url: payload.mapsUrl
    });
    if (error) { console.warn('panico', error.message); NXSB.aviso('No se pudo enviar al servidor: ' + error.message); return { ok:false, error:error.message, bloqueado:/bloquead/i.test(error.message) }; }
    return { ok:true };
  };

  // ── GARITA ────────────────────────────────────────────
  function aAlerta(r){
    return { panicoId: r.id, fecha: new Date(r.creado_en).toLocaleString('es-AR'), mza: r.mza, casa: r.casa,
             tipo: r.tipo, mapsUrl: r.maps_url || '', lat: r.lat, lng: r.lng };
  }
  NXSB.suscribirPanicos = async function(alMostrar){
    const vistos = new Set();
    const emitir = lista => { const n = lista.filter(a => !vistos.has(a.panicoId)); n.forEach(a => vistos.add(a.panicoId)); if (n.length) alMostrar(n); };
    const traer = async () => {
      const desde = new Date(Date.now() - 24*3600*1000).toISOString();
      const { data, error } = await sb.from('panicos').select('*').eq('estado','activo').gte('creado_en', desde).order('creado_en');
      if (error) { NXSB.aviso('Error leyendo pánicos: ' + error.message); return; }
      if (data) emitir(data.map(aAlerta));
    };
    await traer();
    if (NXSB._canal) sb.removeChannel(NXSB._canal);
    const estado = st => {
      NXSB._rt = st === 'SUBSCRIBED' ? ico('dot','#10b981') + 'Tiempo real activo' : ico('dot','#f59e0b') + 'Reconectando… (' + st + ')';
      const d = document.querySelector('#nxsb-gear i'); if (d) d.style.background = st === 'SUBSCRIBED' ? '#10b981' : '#f59e0b';
      const t = document.getElementById('nxsb-rt'); if (t) t.innerHTML = NXSB._rt;
    };
    estado('...');
    const conectar = () => {
      if (NXSB._canal) sb.removeChannel(NXSB._canal);
      NXSB._canal = sb.channel('panicos-' + NXSB.perfil.barrio_id + '-' + Date.now())
        .on('postgres_changes', { event:'INSERT', schema:'public', table:'panicos' }, pl => emitir([aAlerta(pl.new)]))
        .subscribe(st => { estado(st); if (st === 'CHANNEL_ERROR' || st === 'TIMED_OUT') setTimeout(conectar, 5000); });
    };
    conectar();
    // Respaldo: consulta cada 8 s por si el tiempo real se corta (iPhone, red móvil)
    if (NXSB._poll) clearInterval(NXSB._poll);
    NXSB._poll = setInterval(traer, 8000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) traer(); });
  };
  NXSB.confirmarPanicos = async function(ids){
    for (const id of ids) await sb.from('panicos').update({ estado:'confirmado' }).eq('id', id);
  };

  window.addEventListener('DOMContentLoaded', () => { if (window.NXSB_AUTO !== false) arrancar(); });
})();
