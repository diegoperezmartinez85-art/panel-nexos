// Vecino: avisar que la casa va a estar vacía. La garita lo ve y verifica antes de dejar ingresar a cualquier visita a esa casa.
(function(){
  'use strict';
  const sb = () => window.NXSB && NXSB.sb;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const hoyISO = () => ymd(new Date());
  const masDias = n => { const d = new Date(); d.setDate(d.getDate() + n); return ymd(d); };
  const lindo = iso => iso.split('-').reverse().join('/');
  let ov = null, ocupado = false;

  function estilo(){
    if (document.getElementById('nxcv-css')) return;
    const s = document.createElement('style'); s.id = 'nxcv-css';
    s.textContent = `#nxcv{position:fixed;inset:0;z-index:2147482500;background:radial-gradient(ellipse at 50% -10%,color-mix(in srgb,var(--ac,#8b5cf6) 20%,#0d0d14) 0%,#101016 42%,#070709 100%);color:#fff;overflow:auto;font-family:-apple-system,system-ui,sans-serif;padding:16px;padding-top:calc(16px + env(safe-area-inset-top,0px));padding-bottom:calc(28px + env(safe-area-inset-bottom,0px));-webkit-overflow-scrolling:touch}
    #nxcv h2{margin:0 0 4px;font-size:19px}#nxcv .sub{color:#9ca3af;font-size:13px;margin-bottom:14px;line-height:1.4}
    #nxcv input{width:100%;box-sizing:border-box;margin:5px 0;padding:13px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:#fff;font-size:16px;-webkit-appearance:none;appearance:none;min-height:48px;display:block;text-align:left}
    #nxcv button{width:100%;margin-top:8px;padding:14px;border-radius:12px;border:0;font-size:15px;font-weight:700;cursor:pointer}
    #nxcv .p{background:var(--ac,#8b5cf6);color:#fff;text-shadow:0 1px 2px rgba(0,0,0,.3)}#nxcv .s{background:rgba(255,255,255,.08);color:#ddd}
    #nxcv .card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:18px;box-shadow:0 8px 28px rgba(0,0,0,.3);padding:14px;margin:12px 0}
    #nxcv .m{color:#9ca3af;font-size:12px}#nxcv .msg{font-size:13px;margin-top:8px;min-height:16px;color:#f87171}
    #nxcv .it{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 0;border-top:1px solid rgba(255,255,255,.08)}#nxcv .it:first-child{border-top:0}
    #nxcv .it button{width:auto;margin:0;padding:8px 12px;font-size:13px}
    #nxcv .tag{font-size:11px;font-weight:800;padding:2px 8px;border-radius:20px;background:rgba(var(--acr,139,92,246),.18);color:var(--ac,#a78bfa)}`;
    document.head.appendChild(s);
  }
  function cerrar(){ if (ov) { ov.remove(); ov = null; } }

  async function abrir(){
    if (!sb() || !NXSB.perfil) { alert('Iniciá sesión para avisar casa vacía'); return; }
    estilo(); cerrar();
    ov = document.createElement('div'); ov.id = 'nxcv';
    ov.innerHTML = `<button class="s" id="nxcv-x" style="width:auto;padding:8px 14px;margin:0 0 10px">← Volver</button>
      <h2>🏠 Casa vacía</h2><div class="sub">Avisá desde qué día hasta qué día no vas a estar. La garita lo va a ver y, si alguien quiere ingresar a tu casa en esas fechas, va a verificarlo antes de dejarlo pasar.</div>
      <div class="card"><div class="m">Desde</div><input id="nxcv-d" type="date" value="${hoyISO()}" min="${hoyISO()}">
      <div class="m" style="margin-top:6px">Hasta (el día que volvés)</div><input id="nxcv-h" type="date" value="${masDias(7)}" min="${hoyISO()}">
      <input id="nxcv-c" placeholder="Teléfono para ubicarte (opcional)" inputmode="tel" maxlength="40" autocomplete="off" style="margin-top:10px">
      <input id="nxcv-n" placeholder="Nota (ej: mi hermano tiene llaves)" maxlength="200" autocomplete="off">
      <div class="msg" id="nxcv-m"></div><button class="p" id="nxcv-g">Avisar a la garita</button></div>
      <div class="card"><b>Mis avisos</b><div id="nxcv-l" class="m" style="margin-top:8px">Cargando…</div></div>`;
    document.body.appendChild(ov);
    document.getElementById('nxcv-x').onclick = cerrar;
    document.getElementById('nxcv-g').onclick = guardar;
    document.getElementById('nxcv-d').onchange = function(){ const h = document.getElementById('nxcv-h'); if (h.value < this.value) h.value = this.value; h.min = this.value; };
    lista();
  }

  async function guardar(){
    if (ocupado) return;
    const m = document.getElementById('nxcv-m'); m.style.color = '#f87171'; m.textContent = '';
    const desde = document.getElementById('nxcv-d').value, hasta = document.getElementById('nxcv-h').value;
    if (!desde || !hasta) { m.textContent = 'Elegí las dos fechas.'; return; }
    if (hasta < desde) { m.textContent = 'La fecha de regreso no puede ser anterior a la de salida.'; return; }
    if (hasta < hoyISO()) { m.textContent = 'Esas fechas ya pasaron.'; return; }
    ocupado = true; const b = document.getElementById('nxcv-g'); b.disabled = true; b.textContent = 'Enviando…';
    try {
      const contacto = document.getElementById('nxcv-c').value.trim() || null, nota = document.getElementById('nxcv-n').value.trim() || null;
      const { error } = await sb().from('casas_vacias').insert({ barrio_id: NXSB.perfil.barrio_id, propietario_id: NXSB.perfil.id, desde, hasta, contacto, nota });
      if (error) throw error;
      m.style.color = '#34d399'; m.textContent = '✅ Listo, la garita ya lo sabe.';
      document.getElementById('nxcv-c').value = ''; document.getElementById('nxcv-n').value = '';
      lista();
    } catch (e) { m.textContent = (e && e.message) || 'No se pudo guardar. Probá de nuevo.'; }
    finally { ocupado = false; b.disabled = false; b.textContent = 'Avisar a la garita'; }
  }

  let lista = async function(){
    const el = document.getElementById('nxcv-l'); if (!el) return;
    try {
      const { data, error } = await sb().from('casas_vacias').select('*').eq('propietario_id', NXSB.perfil.id).gte('hasta', hoyISO()).order('desde');
      if (error) throw error;
      if (!data.length) { el.textContent = 'No tenés avisos vigentes.'; return; }
      const hoy = hoyISO();
      el.innerHTML = data.map(r => `<div class="it"><div><b>${lindo(r.desde)} → ${lindo(r.hasta)}</b> <span class="tag">${r.desde <= hoy ? 'En curso' : 'Próximo'}</span>${r.nota ? `<div class="m">${esc(r.nota)}</div>` : ''}</div><button class="s" data-x="${esc(r.id)}">${r.desde <= hoy ? 'Ya volví' : 'Cancelar'}</button></div>`).join('');
      el.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => {
        if (!confirm('¿Quitar este aviso? La garita dejará de verlo.')) return;
        const { error: er } = await sb().from('casas_vacias').delete().eq('id', b.dataset.x);
        if (er) alert('No se pudo quitar: ' + er.message); else lista();
      });
    } catch (e) { el.textContent = 'No se pudieron cargar tus avisos.'; }
  }

  // Estado en el botón de la pantalla principal
  async function estado(){
    const t = document.getElementById('nxcv-txt'); if (!t) return;
    const btn = t.closest('button');
    try {
      if (!window.NXSB || !NXSB.perfil || !sb()) return;
      const { data, error } = await sb().from('casas_vacias').select('desde,hasta').eq('propietario_id', NXSB.perfil.id).gte('hasta', hoyISO()).order('desde').limit(10);
      if (error) throw error;
      const hoy = hoyISO(), act = (data || []).find(r => r.desde <= hoy), prox = (data || []).find(r => r.desde > hoy);
      const corto = iso => iso.split('-').reverse().slice(0, 2).join('/');
      if (act) { t.textContent = 'Casa vacía hasta el ' + corto(act.hasta); btn.classList.add('nxcv-on'); }
      else if (prox) { t.textContent = 'Casa vacía desde el ' + corto(prox.desde); btn.classList.add('nxcv-on'); }
      else { t.textContent = 'Avisar casa vacía'; btn.classList.remove('nxcv-on'); }
    } catch (e) {}
  }
  const _lista = lista;
  lista = async function(){ await _lista(); estado(); };
  let intentos = 0;
  const esperar = setInterval(() => { intentos++; if (window.NXSB && NXSB.perfil) { clearInterval(esperar); estado(); } else if (intentos > 60) clearInterval(esperar); }, 1000);
  window.NXVacia = { abrir };
})();
