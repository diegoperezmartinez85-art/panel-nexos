// Garita: muestra las reservas de amenities de hoy y mañana (solo lectura) con acceso directo a WhatsApp.
(function(){
  'use strict';
  function wa(tel){
    let d = String(tel||'').replace(/\D/g,''); if (!d) return '';
    d = d.replace(/^00/,'');
    if (d.startsWith('54')) { if (d.length === 12 && d[2] !== '9') d = '549' + d.slice(2); }
    else { d = d.replace(/^0/,''); d = '549' + d; }
    return 'https://wa.me/' + d;
  }
  function ymd(f){ return f.getFullYear()+'-'+String(f.getMonth()+1).padStart(2,'0')+'-'+String(f.getDate()).padStart(2,'0'); }
  const esc = s => String(s==null?'':s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  let lista = [];
  const ic = (d,w) => '<svg viewBox="0 0 256 256" fill="currentColor" width="'+(w||18)+'" height="'+(w||18)+'" style="vertical-align:-3px;margin-right:6px" aria-hidden="true">'+d+'</svg>';
  const ICAL = '<path d="M208,32H184V24a8,8,0,0,0-16,0v8H88V24a8,8,0,0,0-16,0v8H48A16,16,0,0,0,32,48V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V48A16,16,0,0,0,208,32ZM72,48v8a8,8,0,0,0,16,0V48h80v8a8,8,0,0,0,16,0V48h24V80H48V48ZM208,208H48V96H208V208Z"/>', IWA = '<path d="M187.58,144.84l-32-16a8,8,0,0,0-8,.5l-14.69,9.8a40.55,40.55,0,0,1-16-16l9.8-14.69a8,8,0,0,0,.5-8l-16-32A8,8,0,0,0,104,64a40,40,0,0,0-40,40,88.1,88.1,0,0,0,88,88,40,40,0,0,0,40-40A8,8,0,0,0,187.58,144.84ZM152,176a72.08,72.08,0,0,1-72-72A24,24,0,0,1,99.29,80.46l11.48,23L101,118a8,8,0,0,0-.73,7.51,56.47,56.47,0,0,0,30.15,30.15A8,8,0,0,0,138,155l14.61-9.74,23,11.48A24,24,0,0,1,152,176ZM128,24A104,104,0,0,0,36.18,176.88L24.83,210.93a16,16,0,0,0,20.24,20.24l34.05-11.35A104,104,0,1,0,128,24Zm0,192a87.87,87.87,0,0,1-44.06-11.81,8,8,0,0,0-6.54-.67L40,216,52.47,178.6a8,8,0,0,0-.66-6.54A88,88,0,1,1,128,216Z"/>';
  const DIAS = ['domingo','lunes','martes','miércoles','jueves','viernes','sábado'];
  function etiqueta(f){ const h=ymd(new Date()), m=ymd(new Date(Date.now()+864e5)); if(f===h) return 'HOY'; if(f===m) return 'MAÑANA'; const d=new Date(f+'T12:00:00'); return (DIAS[d.getDay()]+' '+d.getDate()+'/'+(d.getMonth()+1)).toUpperCase(); }

  const css = document.createElement('style');
  css.textContent = `#nxr-bar{margin:8px 12px;padding:12px 14px;border-radius:16px;background:rgba(139,92,246,.14);border:1px solid rgba(139,92,246,.45);color:#c4b5fd;font:700 14px -apple-system,system-ui,sans-serif;display:flex;justify-content:space-between;align-items:center;cursor:pointer;-webkit-tap-highlight-color:transparent}
  #nxr-bar small{font-weight:500;color:#a5a5b5;display:block;margin-top:2px;font-size:12px}
  #nxr-ov{position:fixed;inset:0;z-index:2147482400;background:#0b0b0e;color:#fff;overflow:auto;font-family:-apple-system,system-ui,sans-serif;padding:16px;padding-top:calc(16px + env(safe-area-inset-top,0px));padding-bottom:calc(24px + env(safe-area-inset-bottom,0px))}
  #nxr-ov h2{margin:8px 0 4px;font-size:20px}#nxr-ov h3{margin:18px 0 6px;color:#c4b5fd;font-size:14px;letter-spacing:1px}
  #nxr-ov .it{background:#1a1a20;border:1px solid #2c2c35;border-radius:14px;padding:12px;margin-bottom:8px}
  #nxr-ov .m{color:#9aa0a6;font-size:13px;margin-top:3px}
  #nxr-ov a.w{display:inline-block;margin-top:8px;padding:8px 12px;border-radius:10px;background:#16a34a;color:#fff;text-decoration:none;font-weight:700;font-size:14px}
  #nxr-ov button{padding:8px 14px;border-radius:10px;border:0;background:#2a2a30;color:#fff;font-size:15px}`;
  document.head.appendChild(css);

  async function cargar(){
    try {
      const sb = window.NXSB && NXSB.sb; if (!sb) return;
      const hoy = new Date(), man = new Date(Date.now()+7*864e5);
      const { data } = await sb.from('reservas').select('*').gte('fecha', ymd(hoy)).lte('fecha', ymd(man)).order('fecha').order('horario');
      lista = data || [];
      pintarBarra();
    } catch(e){}
  }
  function pintarBarra(){
    let b = document.getElementById('nxr-bar');
    if (!b) {
      const mon = document.querySelector('.monitor'); if (!mon) return;
      b = document.createElement('div'); b.id = 'nxr-bar'; b.onclick = abrir;
      mon.parentNode.insertBefore(b, mon.nextSibling);
    }
    const h = ymd(new Date()), deHoy = lista.filter(r => r.fecha === h);
    const prox = deHoy[0], futuras = lista.filter(r => r.fecha > h);
    let sub = prox ? esc(prox.amenity) + ' · ' + esc(prox.horario) + ' · Mza ' + esc(prox.mza||'-') + ' Casa ' + esc(prox.casa||'-') : 'Sin reservas para hoy';
    if (futuras.length) sub += ' · ' + futuras.length + ' próxima' + (futuras.length>1?'s':'');
    b.innerHTML = '<div>' + ic(ICAL) + 'Reservas de hoy: ' + deHoy.length + '<small>' + sub + '</small></div><div>▶</div>';
  }
  function fila(r){
    const link = wa(r.contacto);
    return '<div class="it"><b>' + esc(r.amenity) + '</b> · ' + esc(r.horario) + '<div class="m">Mza ' + esc(r.mza||'-') + ' Casa ' + esc(r.casa||'-') + (r.nombre ? ' · ' + esc(r.nombre) : '') + '</div>' +
      (r.contacto ? (link ? '<a class="w" href="' + link + '" target="_blank" rel="noopener">' + ic(IWA,16) + 'WhatsApp ' + esc(r.contacto) + '</a>' : '<div class="m">' + esc(r.contacto) + '</div>') : '') + '</div>';
  }
  async function abrir(){
    await cargar();
    const h = ymd(new Date()), m = ymd(new Date(Date.now()+864e5));
    const fechas = [...new Set([h, m, ...lista.map(r => r.fecha)])].sort();
    const g = f => lista.filter(r => r.fecha === f).map(fila).join('') || '<div class="m">Sin reservas</div>';
    const ov = document.createElement('div'); ov.id = 'nxr-ov';
    ov.innerHTML = '<button id="nxr-x">← Volver</button><h2>' + ic(ICAL,22) + 'Reservas de amenities</h2><div class="m">Hoy y los próximos 7 días</div>' + fechas.map(f => '<h3>' + etiqueta(f) + '</h3>' + g(f)).join('');
    document.body.appendChild(ov);
    ov.querySelector('#nxr-x').onclick = () => ov.remove();
  }
  document.addEventListener('nx-session-start', () => { cargar(); setInterval(cargar, 60000); });
  window.NXReservasGuardia = { abrir, wa };
})();
