// Guardia con login real: lista negra y casas bloqueadas vienen de Supabase (ya no del Sheet ni de PINs).
(function(){
  'use strict';
  const G = {};
  window.NXGuardia = G;
  const sb = () => window.NXSB && NXSB.sb;
  const esAdmin = () => NXSB.perfil && ['admin_barrio','admin_general'].includes(NXSB.perfil.rol);

  G.cargar = async function(){
    if (!sb()) return;
    const ln = await sb().from('lista_negra').select('*').order('creado_en', { ascending: false });
    if (!ln.error && ln.data) {
      LISTA_NEGRA = ln.data.map(r => ({ id: r.id, pat: (r.patente || '').toUpperCase(), dni: r.dni || '', motivo: r.motivo || '', ts: new Date(r.creado_en).getTime() }));
      try { localStorage.setItem('nx_lista_negra', JSON.stringify(LISTA_NEGRA)); } catch (e) {}
    }
    const bn = await sb().from('baneos').select('*').order('creado_en', { ascending: false });
    if (!bn.error && bn.data) {
      BANEADOS = bn.data.map(b => ({ id: b.id_residente || '', mza: String(b.mza || ''), casa: String(b.casa || ''), motivo: b.motivo || '', ts: new Date(b.creado_en).getTime() }));
      DEVICES_BANEADOS = [];
      try { guardarBaneados(); guardarDevicesBaneados(); } catch (e) {}
    }
    if (typeof renderListaNegra === 'function' && document.getElementById('modal-ln') && document.getElementById('modal-ln').classList.contains('visible')) renderListaNegra();
    if (typeof renderBaneados === 'function' && document.getElementById('modal-baneo') && document.getElementById('modal-baneo').classList.contains('visible')) renderBaneados();
  };


  // ── INGRESOS / SALIDAS ─────────────────────────────────
  const hhmm = d => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const normPat = p => String(p || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

  async function guardarRegistro(it){
    const fila = {
      barrio_id: NXSB.perfil.barrio_id, id_externo: String(it.id), tipo: it.tipo || 'VISITA',
      mza: it.mza || null, casa: it.casa || null, dni: it.dni || null, patente: it.pat || null,
      entrada_en: new Date(it.tsE || Date.now()).toISOString(), registrado_por: NXSB.perfil.id, vigilador: it.vig || NXSB.perfil.nombre
    };
    if (it.hS) fila.salida_en = new Date().toISOString();
    const { error } = await sb().from('registros_acceso').upsert(fila, { onConflict: 'barrio_id,id_externo' });
    if (error) throw error;
  }
  async function guardarProp(d){
    const { error } = await sb().from('propietarios').upsert({
      barrio_id: NXSB.perfil.barrio_id, patente: d.patente, nombre: d.nombre, mza: d.mza, casa: d.casa, observaciones: d.observaciones || null
    }, { onConflict: 'barrio_id,patente' });
    if (error) throw error;
  }
  async function borrarProp(d){
    const { error } = await sb().from('propietarios').delete().eq('barrio_id', NXSB.perfil.barrio_id).eq('patente', d.patente);
    if (error) throw error;
  }
  async function procesar(d){
    if (d.accion === 'agregar_propietario') return guardarProp(d);
    if (d.accion === 'eliminar_propietario') return borrarProp(d);
    if (d.accion) return;            // chat, incidentes, etc.: todavía no migrados
    if (d.pat === undefined) return;
    return guardarRegistro(d);
  }
  const razon = e => /row-level|policy|permission/i.test(e.message || '') ? 'Solo el administrador puede hacer esto' : (e.message || 'error');

  // Propietarios: se sincronizan por separado (si falla otra parte, el directorio igual se actualiza)
  G.sincronizarProp = async function(){
    try {
      const pr = await sb().from('propietarios').select('*').order('patente');
      if (pr.error || !pr.data) return;
      PROPIETARIOS = pr.data.map(p => ({ patente: p.patente || '', nombre: p.nombre || '', mza: p.mza || '', casa: p.casa || '', observaciones: p.observaciones || '', fecha: (p.creado_en || '').slice(0, 10) }));
      try { localStorage.setItem('nx_propietarios', JSON.stringify(PROPIETARIOS)); } catch (e) {}
      try { if (typeof renderPropietarios === 'function') renderPropietarios(); } catch (e) {}
    } catch (e) { console.error('Nexos: propietarios', e); }
  };

  G.sincronizar = async function(manual){
    if (G._sync && Date.now() - (G._syncDesde || 0) < 15000) return;   // si una consulta quedó colgada, se libera a los 15 s
    G._sync = true; G._syncDesde = Date.now();
    const mia = G._syncDesde;
    G.sincronizarProp();
    let paso = 'consulta';
    try {
      const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
      const consulta = sb().from('registros_acceso').select('*')
        .or('salida_en.is.null,salida_en.gte.' + hoy.toISOString()).order('entrada_en').limit(2000);
      const { data, error } = await Promise.race([consulta, new Promise((_, rej) => setTimeout(() => rej(new Error('la consulta tardó demasiado')), 12000))]);
      if (error) throw error;
      paso = 'datos';
      const nube = data.map(r => ({ id: Number(r.id_externo) || new Date(r.entrada_en).getTime(), pat: r.patente || '', tipo: r.tipo || 'VISITA', hE: hhmm(r.entrada_en), hS: r.salida_en ? hhmm(r.salida_en) : '',
        tsE: new Date(r.entrada_en).getTime(), mza: r.mza || '', casa: r.casa || '', dni: r.dni || '', vig: r.vigilador || '' }));
      const ids = new Set(nube.map(x => String(x.id)));
      const pend = DB.filter(x => !ids.has(String(x.id)) && ((Date.now() - (x.tsE || 0) < 180000) || (G._fallidos && G._fallidos.has(String(x.id)))));
      DB = [...nube, ...pend];
      try { lsSet('nx_db', JSON.stringify(DB)); } catch (e) {}
      paso = 'pantalla';
      render();
      setSyncStatus('✔ Sincronizado ' + horaActual() + ' · ' + DB.filter(x => !x.hS).length + ' adentro', 'sync-ok');
    } catch (e) {
      console.error('Nexos sync', paso, e);
      setSyncStatus('⚠ Error (' + paso + '): ' + String((e && e.message) || e).slice(0, 60), 'sync-err');
      if (manual) showToast('⚠ Error al sincronizar: ' + ((e && e.message) || ''));
    } finally { if (G._syncDesde === mia) G._sync = false; }
  };

  G.enviar = function(d){
    triggerSysLedFlash('#0ea5e9');
    if (!navigator.onLine) { _colaOffline.push(d); _guardarCola(); showToast('📵 Guardado sin conexión'); return; }
    G._fallidos = G._fallidos || new Map();
    procesar(d).then(() => { if (d.id != null) G._fallidos.delete(String(d.id)); setTimeout(() => G.sincronizar(), 800); }).catch(e => {
      console.error('Nexos: no se pudo guardar', e);
      if (d.id != null) G._fallidos.set(String(d.id), 1);   // no se borra de la pantalla hasta que se guarde
      if (/row-level|policy|permission/i.test(e.message || '')) { showToast('🔒 ' + razon(e)); return; }
      _colaOffline.push(d); _guardarCola(); showToast('⚠ No se pudo guardar: ' + (e.message || 'sin red') + ' — queda en cola');
    });
  };
  G.vaciarCola = async function(){
    if (!_colaOffline.length) return;
    const pend = [..._colaOffline]; _colaOffline = []; _guardarCola();
    for (const d of pend) { try { await procesar(d); } catch (e) { _colaOffline.push(d); } }
    _guardarCola(); G.sincronizar();
  };

  // ── GUARDIAS EN LÍNEA (presencia en tiempo real, sin Sheet) ──
  G.presencia = function(){
    if (G._pres || !sb() || !NXSB.perfil) return;
    const miNombre = () => (sessionStorage.getItem('nx_vigilador') || NXSB.perfil.nombre || 'Guardia');
    let desde = new Date().toISOString(); try { desde = localStorage.getItem('nx_turno_inicio') || desde; } catch (e) {}
    const clave = NXSB.perfil.id + ':' + Math.random().toString(36).slice(2, 8);
    const ch = sb().channel('presencia-' + NXSB.perfil.barrio_id, { config: { presence: { key: clave } } });
    G._pres = ch;
    const pintar = () => {
      const st = ch.presenceState(), vistos = new Map();
      Object.values(st).forEach(arr => arr.forEach(p => { if (p && p.nombre && !vistos.has(p.nombre)) vistos.set(p.nombre, { nombre: p.nombre, ts: p.ts || Date.now(), desde: p.desde }); }));
      _vigsOnline = [...vistos.values()];
      try { renderVigsOnline(); } catch (e) {}
    };
    const marcar = () => { try { ch.track({ nombre: miNombre(), desde, ts: Date.now() }); } catch (e) {} };
    ch.on('presence', { event: 'sync' }, pintar)
      .subscribe(status => {
        if (status === 'SUBSCRIBED') marcar();
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') { G._pres = null; try { sb().removeChannel(ch); } catch (e) {} setTimeout(G.presencia, 5000); }
      });
    setInterval(marcar, 30000);   // renueva la señal y recoge cambios de nombre
    // Al cerrar sesión, salir de la lista al instante
    if (typeof cerrarSesion === 'function' && !G._csHook) {
      G._csHook = true; const cs = cerrarSesion;
      window.cerrarSesion = function(){ try { ch.untrack(); } catch (e) {} return cs.apply(this, arguments); };
    }
    // El Sheet ya no se usa para esto
    window.fetchVigsOnline = async function(){}; window.heartbeatVigilador = async function(){};
  };

  // ── INCIDENTES, CALENDARIO Y BÚSQUEDA DE INGRESOS ANTERIORES (todo en Supabase) ──
  G.extras = function(){
    const vigNombre = () => sessionStorage.getItem('nx_vigilador') || (NXSB.perfil && NXSB.perfil.nombre) || '';
    const msg = e => String((e && e.message) || e || '').slice(0, 80);
    try { localStorage.removeItem('nx_incidentes'); localStorage.removeItem('nx_cal_notas'); } catch (e) {}

    // Incidentes
    G.cargarIncidentes = async function(){
      try {
        const { data, error } = await sb().from('incidentes').select('*').order('creado_en', { ascending: false }).limit(200);
        if (error || !data) return;
        INCIDENTES = data.map(r => ({ id: Number(r.id_externo) || new Date(r.creado_en).getTime(), ts: new Date(r.creado_en).getTime(), tipo: r.tipo, desc: r.descripcion, vig: r.vigilador || '', foto: r.foto || null }));
        try { actualizarContadorIncidentes(); } catch (e) {}
        const m = document.getElementById('modal-incidentes');
        if (m && m.classList.contains('visible')) { try { renderIncidentes(); } catch (e) {} }
      } catch (e) { console.error('Nexos: incidentes', e); }
    };
    window.guardarIncidentes = function(){ try { actualizarContadorIncidentes(); } catch (e) {} };
    window.incPreviewFoto = function(input){
      const file = input.files[0]; if (!file) return;
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, 900 / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        incFotoData = c.toDataURL('image/jpeg', 0.6); URL.revokeObjectURL(url);
        const prev = document.getElementById('inc-foto-preview'); prev.src = incFotoData; prev.style.display = 'block'; prev.title = 'Tocá para quitar la foto';
      };
      img.onerror = () => { URL.revokeObjectURL(url); showToast('⚠ No se pudo leer la foto'); };
      img.src = url;
    };
    window.incGuardar = async function(){
      const texto = document.getElementById('inc-texto').value.trim();
      if (!texto) { showToast('⚠ Describí el incidente primero'); return; }
      if (G._incBusy) return; G._incBusy = true;
      const id = Date.now(), tipo = incTipoSel, foto = incFotoData || null, vig = vigNombre();
      try {
        const { error } = await sb().from('incidentes').insert({ barrio_id: NXSB.perfil.barrio_id, perfil_id: NXSB.perfil.id, id_externo: String(id), tipo, descripcion: texto.slice(0, 1000), vigilador: vig, foto });
        if (error) throw error;
        INCIDENTES = INCIDENTES.filter(i => i.id !== id); INCIDENTES.unshift({ id, ts: id, tipo, desc: texto, vig, foto });
        document.getElementById('inc-texto').value = ''; incQuitarFoto(); incSelTipo('grave');
        showToast('✅ Incidente registrado'); renderIncidentes(); try { actualizarContadorIncidentes(); } catch (e) {}
      } catch (e) { showToast('❌ No se guardó (' + msg(e) + '). El texto sigue acá, probá de nuevo.'); }
      finally { G._incBusy = false; }
    };
    window.incEliminar = async function(id){
      try {
        const { data, error } = await sb().from('incidentes').delete().eq('barrio_id', NXSB.perfil.barrio_id).eq('id_externo', String(id)).select('id');
        if (error) throw error;
        if (!data || !data.length) { showToast('🔒 Solo podés borrar tus incidentes del último día (o lo borra el administrador)'); return; }
        INCIDENTES = INCIDENTES.filter(i => i.id !== id);
        try { actualizarContadorIncidentes(); } catch (e) {}
        renderIncidentes(); showToast('🗑 Incidente eliminado');
      } catch (e) { showToast('❌ No se pudo borrar: ' + msg(e)); }
    };
    window.incConfirmarBorrar = async function(){
      const id = incPendienteEliminar; incPendienteEliminar = null;
      document.getElementById('confirm-del-overlay').classList.remove('visible');
      if (id !== null) await window.incEliminar(id);
    };
    const abrirInc = window.abrirIncidentes;
    window.abrirIncidentes = function(){ abrirInc(); G.cargarIncidentes(); };
    G.cargarIncidentes(); setInterval(() => { if (!document.hidden) G.cargarIncidentes(); }, 60000);

    // Calendario (notas compartidas entre las guardias del barrio)
    G.cargarCal = async function(){
      try {
        const d = new Date(); d.setMonth(d.getMonth() - 2);
        const { data, error } = await sb().from('calendario_notas').select('*').gte('fecha', d.toISOString().slice(0, 10)).order('creado_en').limit(1000);
        if (error || !data) return;
        const n = {};
        data.forEach(r => { (n[r.fecha] = n[r.fecha] || []).push({ texto: r.texto, ts: new Date(r.creado_en).getTime(), ext: r.id_externo, vig: r.vigilador || '' }); });
        calNotas = n;
        const m = document.getElementById('modal-calendario');
        if (m && m.classList.contains('visible')) { renderCalendario(); if (calDiaSeleccionado && !(document.getElementById('cal-input-nota') || {}).value) calSeleccionarDia(calDiaSeleccionado); }
      } catch (e) { console.error('Nexos: calendario', e); }
    };
    window.calGuardarNotas = function(){};
    window.calGuardarNota = async function(fStr){
      const input = document.getElementById('cal-input-nota'); if (!input) return;
      const texto = input.value.trim(); if (!texto) { showToast('✏ Escribí algo primero'); return; }
      if (G._calBusy) return; G._calBusy = true;
      const ts = Date.now();
      try {
        const { error } = await sb().from('calendario_notas').insert({ barrio_id: NXSB.perfil.barrio_id, perfil_id: NXSB.perfil.id, id_externo: String(ts), fecha: fStr, texto: texto.slice(0, 300), vigilador: vigNombre() });
        if (error) throw error;
        (calNotas[fStr] = calNotas[fStr] || []).push({ texto, ts, ext: String(ts), vig: vigNombre() });
        showToast('✅ Nota guardada'); calSeleccionarDia(fStr); renderCalendario();
      } catch (e) { showToast('❌ No se guardó la nota (' + msg(e) + ')'); }
      finally { G._calBusy = false; }
    };
    window.calBorrarNota = async function(fStr, idx){
      const n = (calNotas[fStr] || [])[idx]; if (!n) return;
      if (!confirm('¿Eliminar esta nota?\n\n"' + String(n.texto).slice(0, 80) + '"\n\nEsta acción no se puede deshacer.')) return;
      try {
        const { data, error } = await sb().from('calendario_notas').delete().eq('barrio_id', NXSB.perfil.barrio_id).eq('id_externo', String(n.ext)).select('id');
        if (error) throw error;
        if (!data || !data.length) { showToast('🔒 No tenés permiso para borrar esta nota'); return; }
        calNotas[fStr].splice(idx, 1); if (!calNotas[fStr].length) delete calNotas[fStr];
        showToast('🗑 Nota eliminada'); calSeleccionarDia(fStr); renderCalendario();
      } catch (e) { showToast('❌ No se pudo borrar: ' + msg(e)); }
    };
    const abrirCal = window.abrirCalendario;
    window.abrirCalendario = function(){ abrirCal(); G.cargarCal(); };
    G.cargarCal();


    // Cierre de turno: queda guardado en Supabase y lo ve la administración
    G.guardarCierre = async function(){
      try {
        const hoyStr = new Date().toLocaleDateString('es-AR');
        const deDia = DB.filter(r => new Date(r.tsE || 0).toLocaleDateString('es-AR') === hoyStr);
        const ini = localStorage.getItem('nx_turno_inicio');
        const iniMs = ini ? new Date(ini).getTime() : NaN;
        const incs = INCIDENTES.filter(i => isNaN(iniMs) ? new Date(i.ts).toLocaleDateString('es-AR') === hoyStr : i.ts >= iniMs);
        const fila = {
          barrio_id: NXSB.perfil.barrio_id, perfil_id: NXSB.perfil.id, vigilador: vigNombre(),
          inicio: isNaN(iniMs) ? null : new Date(iniMs).toISOString(),
          total_ingresos: deDia.length, con_salida: deDia.filter(r => r.hS).length, sin_salida: deDia.filter(r => !r.hS).length,
          incidentes: incs.length, graves: incs.filter(i => i.tipo === 'grave').length,
          detalle: {
            ingresos: deDia.map(r => ({ pat: r.pat, dni: r.dni || '', mza: r.mza || '', casa: r.casa || '', tipo: r.tipo || '', hE: r.hE || '', hS: r.hS || '' })),
            incidentes: incs.map(i => ({ tipo: i.tipo, desc: i.desc, vig: i.vig || '', hora: new Date(i.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }))
          }
        };
        const { error } = await Promise.race([sb().from('cierres_turno').insert(fila), new Promise((_, rej) => setTimeout(() => rej(new Error('sin respuesta')), 8000))]);
        if (error) throw error;
        showToast('✅ Cierre enviado a la administración');
      } catch (e) { showToast('⚠ No se pudo enviar el cierre a la administración: ' + msg(e)); }
    };
    const impTurno = window.imprimirTurno;
    window.imprimirTurno = async function(){
      if (!G._cierreBusy) { G._cierreBusy = true; try { await G.guardarCierre(); } finally { setTimeout(() => { G._cierreBusy = false; }, 8000); } }
      impTurno();
    };


    // Alertas del día: salen de Supabase (los pánicos de hoy del barrio), no del celular
    window.abrirAlertas = async function(){
      const cont = document.getElementById('alertas-contenido');
      cont.innerHTML = '<div class="empty-msg">Cargando…</div>'; abrirModal('modal-alertas');
      try {
        const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
        const { data, error } = await Promise.race([sb().from('panicos').select('*').gte('creado_en', hoy.toISOString()).order('creado_en', { ascending: false }).limit(200), new Promise((_, rej) => setTimeout(() => rej(new Error('tardó demasiado')), 10000))]);
        if (error) throw error;
        cont.innerHTML = data.length ? data.map(r => {
          const info = obtenerInfoTipo(r.tipo);
          const mapa = (r.maps_url || '').trim() || (r.lat && r.lng ? 'https://maps.google.com/?q=' + r.lat + ',' + r.lng : '');
          const conf = r.estado === 'confirmado';
          return `<div class="modal-row" style="border-left:4px solid ${info.color}"><strong style="color:${info.color}">${info.icono} ${info.texto}</strong><span style="float:right;font-size:11px;color:#888">${hhmm(r.creado_en)}</span><br><span style="font-size:14px;font-weight:800">🏠 Mza ${escHtml(r.mza || '')} — Casa ${escHtml(r.casa || '')}</span><span style="float:right;font-size:10px;font-weight:800;color:${conf ? 'var(--green)' : 'var(--red)'}">${conf ? '✔ Atendida' : '⚠ Sin confirmar'}</span><br>${mapa ? `<a href="${escHtml(mapa)}" target="_blank" style="color:var(--green);font-size:12px">📍 Ver en Maps</a>` : '<span style="font-size:11px;color:#555">Sin GPS</span>'}</div>`;
        }).join('') : '<div class="empty-msg">Sin alertas hoy 🟢</div>';
      } catch (e) { cont.innerHTML = '<div class="empty-msg">⚠ No se pudieron cargar las alertas: ' + escHtml(msg(e)) + '</div>'; }
    };


    // Autorizados permanentes (los carga el administrador): la garita los reconoce por patente o DNI
    const san = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    G.AUT = []; try { G.AUT = JSON.parse(localStorage.getItem('nx_autorizados') || '[]'); } catch (e) {}
    G.sincronizarAut = async function(){
      try {
        const { data, error } = await sb().from('autorizados').select('*').eq('activo', true).limit(2000);
        if (error || !data) return;
        G.AUT = data; try { localStorage.setItem('nx_autorizados', JSON.stringify(data)); } catch (e) {}
      } catch (e) {}
    };
    G.buscarAut = function(pat, dni){
      const p = san(pat), dd = String(dni || '').trim(), d = /^\d{6,9}$/.test(dd) ? dd : '';
      return G.AUT.find(x => (x.patente && p.length >= 6 && san(x.patente) === p) || (x.dni && d && x.dni === d)) || null;
    };
    G.autEstado = function(a){
      const n = new Date(), ymd = n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0');
      if (a.valido_hasta && a.valido_hasta < ymd) return 'su autorización venció el ' + a.valido_hasta.split('-').reverse().join('/');
      if (a.dias && a.dias.length && !a.dias.includes(n.getDay())) return 'hoy no es un día autorizado';
      if (a.hora_desde && a.hora_hasta) {
        const m = x => { const [h, mi] = String(x).split(':'); return (+h) * 60 + (+mi); };
        const ahora = n.getHours() * 60 + n.getMinutes(), d = m(a.hora_desde), h = m(a.hora_hasta);
        const dentro = d <= h ? (ahora >= d && ahora <= h) : (ahora >= d || ahora <= h);
        if (!dentro) return 'está fuera de su horario (' + String(a.hora_desde).slice(0, 5) + ' a ' + String(a.hora_hasta).slice(0, 5) + ')';
      }
      return '';
    };
    G.sincronizarAut(); setInterval(() => { if (!document.hidden) G.sincronizarAut(); }, 60000);
    const registrarRapido0 = window.registrarRapido;
    window.registrarRapido = function(tipo){
      if (tipo === 'ingreso') {
        const val = (document.getElementById('buscador').value || '').trim().toUpperCase();
        const a = val && G.buscarAut(val, val);
        if (a) {
          try { verificarListaNegra(val, val); } catch (e) {}
          const est = G.autEstado(a);
          if (est && !confirm('⚠ ' + a.nombre + ' figura como autorizado, pero ' + est + '.\n\n¿Registrar el ingreso igual?')) return;
          const item = { id: Date.now(), pat: val, tipo: 'AUTORIZADO', hE: horaActual(), hS: '', tsE: Date.now(), mza: a.mza, casa: a.casa, dni: a.dni || '', vig: vigNombre() };
          DB.push(item); try { lsSet('nx_db', JSON.stringify(DB)); } catch (e) {}
          render(); enviar(item); document.getElementById('buscador').value = '';
          showToast('✅ AUTORIZADO: ' + a.nombre + (a.relacion ? ' (' + a.relacion + ')' : '') + ' · Mza ' + a.mza + ' Casa ' + a.casa);
          try { emitirAlertaVoz('Autorizado ' + a.nombre); } catch (e) {}
          return;
        }
      }
      return registrarRapido0.apply(this, arguments);
    };
    const autoformatear0 = window.autoformatearPatente;
    if (autoformatear0) window.autoformatearPatente = function(input){
      autoformatear0.apply(this, arguments);
      if (input && (input.id === 'm-pat' || input.id === 'd-pat')) {
        const a = G.buscarAut(input.value, '');
        if (a && input._nxAut !== a.id) {
          input._nxAut = a.id;
          const pre = input.id === 'm-pat' ? 'm-' : 'd-', mz = document.getElementById(pre + 'mza'), cs = document.getElementById(pre + 'casa');
          if (mz && cs && (!mz.value || !cs.value)) { mz.value = a.mza; cs.value = a.casa; }
          const est = G.autEstado(a);
          showToast((est ? '⚠ ' : '✅ ') + 'AUTORIZADO: ' + a.nombre + (a.relacion ? ' (' + a.relacion + ')' : '') + ' · Mza ' + a.mza + ' Casa ' + a.casa + (est ? ' — ' + est : ''));
        } else if (!a) input._nxAut = null;
      }
    };
    const enviar0 = window.enviar;
    window.enviar = function(d){
      if (d && d.tipo === 'VISITA' && !d.accion && !d.hS) {
        const a = G.buscarAut(d.pat, d.dni);
        if (a) { d.tipo = 'AUTORIZADO'; if (!d.mza) d.mza = a.mza; if (!d.casa) d.casa = a.casa; }
      }
      if (d && !d.accion && !d.hS && d.mza && d.casa) { try { G.cvAviso(d.mza, d.casa); } catch (e) {} }
      return enviar0.apply(this, arguments);
    };

    // Casas vacías: el propietario avisa desde su app; la garita lo ve y verifica antes de dejar pasar
    const normCV = x => String(x || '').trim().toUpperCase().replace(/^0+(?=\d)/, '');
    const ymdCV = () => { const n = new Date(); return n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0'); };
    const lindoCV = iso => String(iso).split('-').reverse().join('/');
    G.CV = []; try { G.CV = JSON.parse(localStorage.getItem('nx_casas_vacias') || '[]'); } catch (e) {}
    G.sincronizarCV = async function(){
      try {
        const { data, error } = await sb().from('casas_vacias').select('*').gte('hasta', ymdCV()).order('desde').limit(500);
        if (error || !data) return;
        G.CV = data; try { localStorage.setItem('nx_casas_vacias', JSON.stringify(data)); } catch (e) {}
      } catch (e) {}
    };
    G.cvDe = function(mza, casa){
      const m = normCV(mza), c = normCV(casa); if (!m || !c) return null;
      const h = ymdCV();
      return G.CV.find(r => r.desde <= h && r.hasta >= h && normCV(r.mza) === m && normCV(r.casa) === c) || null;
    };
    G._cvVisto = {};
    G.cvAviso = function(mza, casa){
      const r = G.cvDe(mza, casa); if (!r) return false;
      const k = normCV(mza) + '|' + normCV(casa), t = Date.now();
      if (G._cvVisto[k] && t - G._cvVisto[k] < 120000) return true;
      G._cvVisto[k] = t;
      const old = document.getElementById('nx-cv-aviso'); if (old) old.remove();
      const tel = String(r.contacto || '').replace(/[^0-9+]/g, '');
      const ov = document.createElement('div'); ov.id = 'nx-cv-aviso';
      ov.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.82);display:flex;align-items:center;justify-content:center;padding:20px;font-family:inherit';
      ov.innerHTML = `<div style="width:100%;max-width:380px;background:#14141a;border:2px solid #f59e0b;border-radius:22px;padding:22px;text-align:center;box-shadow:0 0 40px rgba(245,158,11,.35)">
        <div style="font-size:42px">🏠</div>
        <div style="font-size:20px;font-weight:900;color:#f59e0b;letter-spacing:.5px;margin:4px 0">CASA VACÍA</div>
        <div style="font-size:24px;font-weight:900;color:#fff;margin:6px 0">Mza ${escHtml(r.mza || '')} — Casa ${escHtml(r.casa || '')}</div>
        <div style="color:#d4d4d8;font-size:14px;line-height:1.45">El propietario avisó que <b>no hay nadie</b> hasta el <b>${lindoCV(r.hasta)}</b>.<br>Verificá con él antes de dejar ingresar.</div>
        ${r.contacto ? `<a href="tel:${escHtml(tel)}" style="display:block;margin-top:12px;padding:12px;border-radius:12px;background:rgba(245,158,11,.14);color:#fbbf24;font-weight:800;text-decoration:none">📞 ${escHtml(r.contacto)}</a>` : ''}
        ${r.nota ? `<div style="margin-top:10px;font-size:13px;color:#a1a1aa">📝 ${escHtml(r.nota)}</div>` : ''}
        <button id="nx-cv-ok" style="width:100%;margin-top:16px;padding:14px;border:0;border-radius:12px;background:#f59e0b;color:#1a1204;font-size:16px;font-weight:900">ENTENDIDO</button></div>`;
      document.body.appendChild(ov);
      document.getElementById('nx-cv-ok').onclick = () => ov.remove();
      try { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch (e) {}
      try { emitirAlertaVoz('Atención. Casa vacía. Manzana ' + r.mza + ' casa ' + r.casa); } catch (e) {}
      return true;
    };
    ['m-', 'd-'].forEach(pre => ['mza', 'casa'].forEach(f => {
      const el = document.getElementById(pre + f);
      if (el) el.addEventListener('change', () => { const mz = document.getElementById(pre + 'mza'), cs = document.getElementById(pre + 'casa'); if (mz && cs && mz.value && cs.value) G.cvAviso(mz.value, cs.value); });
    }));
    // Mascotas perdidas: el vecino las marca y la garita las ve con foto y teléfono
    G.MP = [];
    G.mpPintar = function(){
      const b = document.getElementById('mp-badge'); if (b) { b.textContent = G.MP.length; b.style.display = G.MP.length ? 'inline-block' : 'none'; }
    };
    G.sincronizarMP = async function(){
      try {
        const { data, error } = await sb().from('mascotas').select('*').not('perdida_desde', 'is', null).order('perdida_desde', { ascending: false }).limit(50);
        if (error || !data) return;
        G.MP = data; G.mpPintar();
        let vistos = []; try { vistos = JSON.parse(localStorage.getItem('nx_mp_vistas') || '[]'); } catch (e) {}
        const nuevas = data.filter(m => !vistos.includes(m.id + '|' + m.perdida_desde));
        if (nuevas.length) {
          try { localStorage.setItem('nx_mp_vistas', JSON.stringify(data.map(m => m.id + '|' + m.perdida_desde).slice(0, 100))); } catch (e) {}
          G.mpAlerta(nuevas[0]);
        }
      } catch (e) {}
    };
    G.waNum = function(t){
      let d = String(t || '').replace(/\D/g, ''); if (!d) return '';
      d = d.replace(/^00/, '').replace(/^0+/, '');
      if (d.startsWith('54')) return d.startsWith('549') ? d : '549' + d.slice(2);
      if (d.length === 10) return '549' + d;
      if (d.length === 12 && d.slice(2, 4) === '15') return '549' + d.slice(0, 2) + d.slice(4);
      return '549' + d;
    };
    G.mpFoto = function(src){
      const v = document.createElement('div');
      v.style.cssText = 'position:fixed;inset:0;z-index:2147483200;background:#000;display:flex;align-items:center;justify-content:center;padding:12px';
      v.innerHTML = '<img src="' + src + '" style="max-width:100%;max-height:100%;object-fit:contain;border-radius:8px"><button style="position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:14px;width:44px;height:44px;border-radius:50%;border:0;background:rgba(255,255,255,.18);color:#fff;font-size:22px">✕</button>';
      v.onclick = () => v.remove(); document.body.appendChild(v);
    };
    G.mpContacto = function(m, estilo){
      const raw = m.perdida_contacto || m.telefono; if (!raw) return '';
      const tel = String(raw).replace(/[^0-9+]/g, ''), wa = G.waNum(raw);
      return `<div style="display:flex;gap:8px;margin-top:10px"><a href="tel:${escHtml(tel)}" style="flex:1;padding:11px;border-radius:12px;background:rgba(56,189,248,.14);color:#7dd3fc;font-weight:800;text-decoration:none;text-align:center">📞 Llamar</a><a href="https://wa.me/${escHtml(wa)}" target="_blank" rel="noopener" style="flex:1;padding:11px;border-radius:12px;background:rgba(37,211,102,.16);color:#4ade80;font-weight:800;text-decoration:none;text-align:center">💬 WhatsApp</a></div><div style="font-size:12px;color:#a1a1aa;margin-top:6px;text-align:center">${escHtml(raw)}</div>`;
    };
    G.mpAlerta = function(m){
      const old = document.getElementById('nx-mp-aviso'); if (old) old.remove();
      const tel = String(m.perdida_contacto || m.telefono || '').replace(/[^0-9+]/g, '');
      const ov = document.createElement('div'); ov.id = 'nx-mp-aviso';
      ov.style.cssText = 'position:fixed;inset:0;z-index:2147482900;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:20px;font-family:inherit';
      ov.innerHTML = `<div style="width:100%;max-width:380px;background:#14141a;border:2px solid #38bdf8;border-radius:22px;padding:22px;text-align:center;box-shadow:0 0 40px rgba(56,189,248,.3)">
        <div style="font-size:18px;font-weight:900;color:#38bdf8;letter-spacing:.5px">🐕 MASCOTA PERDIDA</div>
        ${m.foto_url ? `<img src="${escHtml(m.foto_url)}" onclick="NXGuardia.mpFoto(this.src)" style="width:150px;height:150px;object-fit:cover;border-radius:50%;border:3px solid #38bdf8;margin:12px 0 2px"><div style="font-size:11px;color:#7dd3fc;margin-bottom:4px">Tocá la foto para verla grande</div>` : '<div style="font-size:60px;margin:8px 0">🐾</div>'}
        <div style="font-size:24px;font-weight:900;color:#fff">${escHtml(m.nombre || '')}</div>
        <div style="color:#a1a1aa;font-size:14px;margin-top:2px">${escHtml(m.raza || '')}</div>
        <div style="color:#d4d4d8;font-size:15px;font-weight:700;margin-top:8px">Mza ${escHtml(m.mza || '-')} — Casa ${escHtml(m.casa || '-')}</div>
        ${m.perdida_nota ? `<div style="margin-top:8px;font-size:13px;color:#a1a1aa">📝 ${escHtml(m.perdida_nota)}</div>` : ''}
        ${G.mpContacto(m)}
        <div style="margin-top:10px;font-size:12px;color:#a1a1aa">Estén atentos a la salida de vehículos.</div>
        <button id="nx-mp-ok" style="width:100%;margin-top:14px;padding:14px;border:0;border-radius:12px;background:#38bdf8;color:#04202e;font-size:16px;font-weight:900">ENTENDIDO</button></div>`;
      document.body.appendChild(ov);
      document.getElementById('nx-mp-ok').onclick = () => ov.remove();
      try { if (navigator.vibrate) navigator.vibrate([150, 80, 150]); } catch (e) {}
      try { emitirAlertaVoz('Atención. Mascota perdida. ' + (m.nombre || '')); } catch (e) {}
    };
    window.abrirMascotasPerdidas = async function(){
      const cont = document.getElementById('mascotas-contenido');
      cont.innerHTML = '<div class="empty-msg">Cargando…</div>'; abrirModal('modal-mascotas');
      await G.sincronizarMP();
      cont.innerHTML = G.MP.length ? G.MP.map(m => `<div class="modal-row" style="border-left:4px solid #38bdf8;display:flex;gap:12px;align-items:center">${m.foto_url ? `<img src="${escHtml(m.foto_url)}" onclick="NXGuardia.mpFoto(this.src)" style="width:64px;height:64px;object-fit:cover;border-radius:50%;flex-shrink:0;cursor:pointer">` : '<div style="font-size:36px;width:64px;text-align:center">🐾</div>'}<div style="flex:1;min-width:0"><strong style="font-size:16px">${escHtml(m.nombre || '')}</strong> <span style="color:#888;font-size:12px">${escHtml(m.raza || '')}</span><br>Mza ${escHtml(m.mza || '-')} — Casa ${escHtml(m.casa || '-')}${m.perdida_nota ? `<br><span style="font-size:12px;color:#888">📝 ${escHtml(m.perdida_nota)}</span>` : ''}${G.mpContacto(m)}</div></div>`).join('') : '<div class="empty-msg">Ninguna mascota perdida 🟢</div>';
    };
    G.sincronizarMP(); setInterval(() => { if (!document.hidden) G.sincronizarMP(); }, 45000);
    G.sincronizarCV(); setInterval(() => { if (!document.hidden) G.sincronizarCV(); }, 60000);
    window.abrirCasasVacias = async function(){
      const cont = document.getElementById('casasvacias-contenido');
      cont.innerHTML = '<div class="empty-msg">Cargando…</div>'; abrirModal('modal-casasvacias');
      await G.sincronizarCV();
      const h = ymdCV(), ahora = G.CV.filter(r => r.desde <= h && r.hasta >= h), prox = G.CV.filter(r => r.desde > h);
      const fila = (r, col) => `<div class="modal-row" style="border-left:4px solid ${col}"><strong style="font-size:15px">🏠 Mza ${escHtml(r.mza || '-')} — Casa ${escHtml(r.casa || '-')}</strong><span style="float:right;font-size:11px;color:#888">${lindoCV(r.desde)} → ${lindoCV(r.hasta)}</span>${r.contacto ? `<br><a href="tel:${escHtml(String(r.contacto).replace(/[^0-9+]/g, ''))}" style="color:var(--green);font-size:12px">📞 ${escHtml(r.contacto)}</a>` : ''}${r.nota ? `<br><span style="font-size:11px;color:#888">📝 ${escHtml(r.nota)}</span>` : ''}</div>`;
      cont.innerHTML = (ahora.length ? '<div class="menu-section-label">VACÍAS AHORA</div>' + ahora.map(r => fila(r, '#f59e0b')).join('') : '<div class="empty-msg">Ninguna casa vacía hoy 🟢</div>')
        + (prox.length ? '<div class="menu-section-label" style="margin-top:12px">PRÓXIMAS</div>' + prox.map(r => fila(r, '#6b7280')).join('') : '');
    };

    // Buscar ingresos anteriores (por fecha o por patente/DNI)
    window.hsConsultar = async function(p){
      const status = document.getElementById('hs-status'), cont = document.getElementById('hs-resultados');
      status.innerText = '🔍 Buscando...'; cont.innerHTML = getSkeletonHtml(3);
      try {
        let q = sb().from('registros_acceso').select('*');
        if (p.fecha) {
          const [a, m, d] = p.fecha.split('-').map(Number);
          q = q.gte('entrada_en', new Date(a, m - 1, d).toISOString()).lt('entrada_en', new Date(a, m - 1, d + 1).toISOString()).order('entrada_en', { ascending: false }).limit(500);
        } else {
          const t = String(p.q || '').replace(/[^A-Za-z0-9]/g, '');
          if (!t) { status.innerText = ''; cont.innerHTML = ''; return; }
          q = q.or('patente.ilike.%' + t + '%,dni.ilike.%' + t + '%').order('entrada_en', { ascending: false }).limit(200);
        }
        const { data, error } = await Promise.race([q, new Promise((_, rej) => setTimeout(() => rej(new Error('tardó demasiado')), 15000))]);
        if (error) throw error;
        status.innerText = data.length + ' resultado(s)' + (data.length >= (p.fecha ? 500 : 200) ? ' (mostrando los más recientes)' : '');
        if (!data.length) { cont.innerHTML = '<div class="empty-msg">Sin resultados</div>'; return; }
        cont.innerHTML = data.map(r => {
          const hS = r.salida_en ? hhmm(r.salida_en) : '';
          const fecha = new Date(r.entrada_en).toLocaleDateString('es-AR');
          return `<div class="modal-row" style="border-left:4px solid ${hS ? 'var(--border)' : 'var(--green)'}"><strong style="font-size:15px;">${escHtml(r.patente || '-')}</strong>${r.dni ? ` · DNI: ${escHtml(r.dni)}` : ''}<span style="float:right;font-size:11px;color:${hS ? '#888' : 'var(--green)'};font-weight:800;">${hS ? '✔ Salió ' + hS : '⚡ Sin salida'}</span><br><span style="font-size:11px;color:#888;">Mza ${escHtml(r.mza || '-')} — Casa ${escHtml(r.casa || '-')} · ${escHtml(r.tipo || '')}</span><br><span style="font-size:11px;color:#555;">Entró: ${fecha} ${hhmm(r.entrada_en)}${r.vigilador ? ' · 👤 ' + escHtml(r.vigilador) : ''}</span></div>`;
        }).join('');
      } catch (e) { status.innerText = '⚠ Error al buscar: ' + msg(e); cont.innerHTML = ''; }
    };
  };

  G.iniciar = function(){
    // Esta sesión no usa el Sheet viejo
    try { localStorage.removeItem('nx_url'); } catch (e) {}
    G.cargar();
    setInterval(G.cargar, 60000);
    window.enviar = G.enviar; window._vaciarCola = G.vaciarCola; window.sincronizar = G.sincronizar;
    G.presencia();
    G.extras();
    G.sincronizarProp(); G.sincronizar(); setInterval(() => { if (!document.hidden) G.sincronizar(); }, 8000);
    if (_colaOffline.length) G.vaciarCola();
    setInterval(() => { if (_colaOffline.length && navigator.onLine) G.vaciarCola(); }, 30000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) G.cargar(); });

    // Lista negra: sin PIN; la guardia agrega, solo el administrador quita.
    window.mostrarAgregarLN = function(){
      document.getElementById('ln-vista-consulta').style.display = 'none';
      document.getElementById('ln-vista-agregar').style.display = 'none';
      document.getElementById('ln-vista-form').style.display = 'block';
      ['ln-form-pat', 'ln-form-dni', 'ln-form-motivo'].forEach(id => document.getElementById(id).value = '');
    };
    window.agregarListaNegra = async function(){
      const pat = document.getElementById('ln-form-pat').value.trim().toUpperCase();
      const dni = document.getElementById('ln-form-dni').value.trim();
      const motivo = document.getElementById('ln-form-motivo').value.trim();
      if (!pat && !dni) { showToast('⚠ Ingresá al menos patente o DNI'); return; }
      const { error } = await sb().from('lista_negra').insert({ patente: pat || null, dni: dni || null, motivo: motivo || null, barrio_id: NXSB.perfil.barrio_id });
      if (error) { showToast('❌ No se pudo agregar: ' + error.message); return; }
      showToast('🚫 Agregado a lista negra');
      ocultarAgregarLN(); await G.cargar(); renderListaNegra();
    };
    window.pedirPinQuitarLN = async function(idx){
      const item = LISTA_NEGRA[idx];
      if (!item) return;
      if (!esAdmin() || !item.id) { showToast('🔒 Solo el administrador del barrio puede quitar de la lista negra'); return; }
      if (!confirm('¿Quitar ' + (item.pat || item.dni) + ' de la lista negra?')) return;
      const { error } = await sb().from('lista_negra').delete().eq('id', item.id);
      if (error) { showToast('❌ ' + error.message); return; }
      showToast('✅ Eliminado de lista negra'); await G.cargar(); renderListaNegra();
    };


    // ── PASES QR de visitas: se validan contra el servidor (existe, vigente, no usado) ──
    const qrOrig = window.qrProcesar, confOrig = window.confirmarIngresoQR;
    const denegar = (msg) => {
      const icon = document.querySelector('.qr-result-icon'), t = document.querySelector('.qr-result-title'), b = document.getElementById('qr-btn-confirm');
      if (icon) { if (window.qrIcono) qrIcono('no'); else icon.innerText = '❌'; }
      if (t) { t.innerText = msg; t.style.color = 'var(--red)'; t.style.textShadow = ''; }
      if (b) { b.disabled = true; b.style.opacity = '.35'; b.style.background = ''; b.style.color = ''; b.innerText = '🚫 NO PUEDE INGRESAR'; }
      if (typeof emitirAlertaVoz === 'function') emitirAlertaVoz('Pase no válido');
    };
    // ── Documentos de la visita (DNI, registro, seguro) adjuntos al pase ──
    const DOCS = [['dni', 'DNI'], ['registro', 'Registro'], ['seguro', 'Seguro']];
    function docsBox(){
      let el = document.getElementById('qr-docs');
      if (!el) {
        el = document.createElement('div'); el.id = 'qr-docs';
        el.style.cssText = 'display:none;margin:12px 0 4px;padding:10px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08)';
        const btn = document.getElementById('qr-btn-confirm'); btn.parentNode.insertBefore(el, btn);
      }
      return el;
    }
    function verDoc(url, titulo){
      const v = document.createElement('div');
      v.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.96);display:flex;flex-direction:column;padding-top:env(safe-area-inset-top,0px)';
      v.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;color:#fff;font:800 15px -apple-system,system-ui,sans-serif"><span>' + titulo + '</span><button style="background:rgba(255,255,255,.12);color:#fff;border:0;border-radius:10px;padding:10px 16px;font:700 14px -apple-system,system-ui,sans-serif">✕ Cerrar</button></div>'
        + '<div class="dz" style="flex:1;overflow:auto;-webkit-overflow-scrolling:touch;display:flex;align-items:center;justify-content:center"><img src="' + url + '" style="max-width:100%;max-height:100%;object-fit:contain;transition:width .15s"></div>'
        + '<div style="color:#a1a1aa;text-align:center;font:600 12px -apple-system,system-ui,sans-serif;padding:10px 0 calc(14px + env(safe-area-inset-bottom,0px))">Tocá la foto para ampliar</div>';
      const img = v.querySelector('img'), dz = v.querySelector('.dz'); let zoom = false;
      img.onclick = () => { zoom = !zoom;
        if (zoom) { img.style.maxWidth = 'none'; img.style.maxHeight = 'none'; img.style.width = '250%'; dz.style.display = 'block'; }
        else { img.style.width = ''; img.style.maxWidth = '100%'; img.style.maxHeight = '100%'; dz.style.display = 'flex'; } };
      v.querySelector('button').onclick = () => v.remove();
      document.body.appendChild(v);
    }
    async function mostrarDocs(r){
      const el = docsBox(); const d = (r && r.docs) || {};
      const hay = DOCS.filter(([k]) => d[k]);
      if (!hay.length) { el.style.display = 'block'; el.innerHTML = '<div style="font:700 12px -apple-system,system-ui,sans-serif;color:#a1a1aa;text-align:center">Sin documentos adjuntos</div>'; return; }
      const vence = d.seguro_vence ? new Date(d.seguro_vence + 'T23:59:59') : null, vencido = vence && vence < new Date();
      el.style.display = 'block';
      el.innerHTML = '<div style="font:800 12px -apple-system,system-ui,sans-serif;color:#e4e4e7;margin-bottom:8px;letter-spacing:.3px;display:flex;align-items:center;gap:6px"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.5l-8.2 8.2a5 5 0 0 1-7.1-7.1l8.6-8.6a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l7.9-7.9"/></svg>DOCUMENTOS DE LA VISITA</div>'
        + '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">' + DOCS.map(([k, t]) => d[k]
          ? '<div data-k="' + k + '" style="position:relative;aspect-ratio:1/1;border-radius:10px;overflow:hidden;background:#18181b;border:1.5px solid rgba(16,185,129,.6);cursor:pointer"><img alt="" style="width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .2s"><span style="position:absolute;left:0;right:0;bottom:0;background:rgba(0,0,0,.6);color:#fff;font:700 11px -apple-system,system-ui,sans-serif;text-align:center;padding:3px">✓ ' + t + '</span></div>'
          : '<div style="aspect-ratio:1/1;border-radius:10px;border:1.5px dashed rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;text-align:center;color:#71717a;font:700 11px -apple-system,system-ui,sans-serif">' + t + '<br>no adjunto</div>').join('') + '</div>'
        + (vence ? '<div style="margin-top:8px;font:800 12px -apple-system,system-ui,sans-serif;text-align:center;color:' + (vencido ? '#f87171' : '#86efac') + '">Seguro ' + (vencido ? 'VENCIDO' : 'vigente') + ' · vence ' + d.seguro_vence.split('-').reverse().join('/') + '</div>' : '');
      try {
        const { data } = await sb().storage.from('docs-visitas').createSignedUrls(hay.map(([k]) => d[k]), 300);
        const m = {}; (data || []).forEach(x => { if (x.signedUrl) m[x.path] = x.signedUrl; });
        el.querySelectorAll('[data-k]').forEach(t => {
          const k = t.dataset.k, u = m[d[k]], img = t.querySelector('img');
          if (!u) { t.querySelector('span').textContent = 'No disponible'; return; }
          img.onload = () => { img.style.opacity = 1; }; img.src = u;
          t.onclick = () => verDoc(u, (DOCS.find(x => x[0] === k) || [k, k])[1]);
        });
      } catch (e) {}
    }

    window.qrProcesar = async function(raw){
      G._pase = null;
      { const el = document.getElementById('qr-docs'); if (el) { el.style.display = 'none'; el.innerHTML = ''; } }
      const m = /Pase[:\s]+([A-Z0-9]{6,12})/i.exec(String(raw || ''));
      if (!m) {
        qrOrig(raw);
        if (!/propietario/i.test((document.getElementById('qr-raw-display') || {}).innerText || '')) showToast('⚠ QR sin pase verificado — confirmá con el propietario');
        return;
      }
      const cod = m[1].toUpperCase();
      const { data: r, error } = await sb().from('visitas_qr').select('*').eq('codigo', cod).maybeSingle();
      if (error) { qrOrig(raw); showToast('⚠ No se pudo verificar el pase (sin conexión)'); return; }
      if (!r) { qrOrig(''); denegar('PASE NO EXISTE'); return; }
      const f = d => { const x = new Date(d); return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'); };
      const txt = 'INGRESO NEXOS\nVisita: ' + r.visitante + '\nPatente: ' + (r.patente || '') + '\nDNI: ' + (r.dni || '') + '\nMza:' + (r.mza || '') + ' Casa:' + (r.casa || '') + '\nFecha: ' + f(new Date());
      qrOrig(txt);
      mostrarDocs(r);
      const now = Date.now();
      if (r.usado_en) { denegar('PASE YA UTILIZADO (' + hhmm(r.usado_en) + ')'); return; }
      if (new Date(r.valido_hasta).getTime() < now) { denegar('PASE VENCIDO (' + f(r.valido_hasta).split('-').reverse().join('/') + ')'); return; }
      if (new Date(r.valido_desde).getTime() > now) { denegar('PASE PARA OTRO DÍA (' + f(r.valido_desde).split('-').reverse().join('/') + ')'); return; }
      G._pase = r.codigo;
    };
    window.confirmarIngresoQR = async function(){
      const antes = DB.length, cod = G._pase;
      confOrig();
      if (cod && DB.length > antes) {
        G._pase = null;
        const { error } = await sb().from('visitas_qr').update({ usado_en: new Date().toISOString() }).eq('codigo', cod);
        if (error) showToast('⚠ No se pudo marcar el pase como usado');
      }
    };

    // Bloqueos de casas: la guardia solo consulta; se gestionan desde el panel del administrador.
    const aviso = () => showToast('🔒 Los bloqueos los gestiona el administrador desde su panel');
    window.mostrarPinBaneo = aviso;
    window.confirmarBaneo = aviso;
    window.enviarBaneo = function(){}; window.enviarListaNegra = function(){};
    // Quitar un bloqueo también es solo del administrador
    window.pedirPinDesbanear = aviso;
  };
})();
